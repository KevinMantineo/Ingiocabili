class WeatherWidget {
    constructor(apiKey, city, containerId) {
        this.apiKey = apiKey;
        this.city = city;
        this.container = document.getElementById(containerId);
        this.baseURL = 'https://api.openweathermap.org/data/2.5/forecast';
        this.init();
    }

    async init() {
        if (!this.city || this.city.trim() === "") {
            this.showError('Città non disponibile per il meteo.');
            return;
        }
        try {
            const forecastData = await this.fetchForecastData(this.city);
            this.renderForecast(forecastData);
        } catch (error) {
            this.showError('Impossibile recuperare i dati meteo: ' + error.message);
        }
    }

    async fetchForecastData(city) {
        const url = `${this.baseURL}?q=${encodeURIComponent(city)}&appid=${this.apiKey}&units=metric&lang=it`;
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('Errore nella richiesta API');
        }
        return await response.json();
    }

    getWeatherIcon(iconCode) {
        const iconMap = {
            '01d': '☀️', '01n': '🌙',
            '02d': '⛅', '02n': '☁️',
            '03d': '☁️', '03n': '☁️',
            '04d': '☁️', '04n': '☁️',
            '09d': '🌧️', '09n': '🌧️',
            '10d': '🌦️', '10n': '🌦️',
            '11d': '⛈️', '11n': '⛈️',
            '13d': '❄️', '13n': '❄️',
            '50d': '🌫️', '50n': '🌫️'
        };
        return iconMap[iconCode] || '🌈';
    }

    renderForecast(data) {
        // Calcola la data "oggi" in Italia (Europe/Rome)
        const now = new Date();
        // Ottieni la data locale italiana in formato YYYY-MM-DD
        const todayStr = now.toLocaleDateString('it-IT').split('/').reverse().join('-'); // "YYYY-MM-DD"

        // Filtra tutte le previsioni che sono per oggi in Italia
        const todayForecasts = data.list.filter(item => {
            // item.dt_txt è in formato "YYYY-MM-DD HH:MM:SS" in UTC
            // Prendi solo la parte della data
            return item.dt_txt.startsWith(todayStr);
        });

        if (todayForecasts.length === 0) {
            this.showError('Nessuna previsione disponibile per oggi.');
            return;
        }

        let forecastHTML = `
            <div class="weather-container">
                <h2>Meteo oggi - ${data.city.name}</h2>
                <table class="weather-table">
                    <thead>
                        <tr>
                            <th>Ora</th>
                            <th>Icona</th>
                            <th>Temperatura</th>
                            <th>Descrizione</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        todayForecasts.forEach(item => {
            // Ora locale italiana
            const itemDate = new Date(item.dt * 1000);
            const hour = itemDate.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
            forecastHTML += `
                <tr>
                    <td>${hour}</td>
                    <td class="weather-icon">${this.getWeatherIcon(item.weather[0].icon)}</td>
                    <td>${Math.round(item.main.temp)}°C</td>
                    <td>${item.weather[0].description}</td>
                </tr>
            `;
        });

        forecastHTML += `
                    </tbody>
                </table>
                <div style="margin-top: 10px; font-size: 0.9em;">
                    Aggiornato: ${new Date().toLocaleTimeString('it-IT')}
                </div>
            </div>
        `;

        this.container.innerHTML = forecastHTML;
    }

    showError(message) {
        this.container.innerHTML = `
            <div class="error">
                <h3>❌ Errore</h3>
                <p>${message}</p>
                <button onclick="location.reload()">Riprova</button>
            </div>
        `;
    }
}

document.addEventListener('DOMContentLoaded', function() {
    new WeatherWidget(weatherApiKey, weatherCity, 'weatherWidget');
});