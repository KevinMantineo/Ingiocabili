<?php
session_start();
require_once '../db.php';

// Connessione al DB
$mysqli = new mysqli($servername, $username, $password, $dbname);
if ($mysqli->connect_error) {
    die('Errore di connessione al database.');
}

// CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}

// Se già loggato, vai alla homepage
if (isset($_SESSION['token'])) {
    header('Location: /RoadPulse/Main/Homepage.php');
    exit;
}

// Logout (se mai lo userai da questa pagina)
if (isset($_POST['logout'])) {
    $_SESSION = [];
    session_destroy();
    header('Location: login.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['logout'])) {
    // Verifica token CSRF
    if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['csrf_token']) {
        $error = 'Token CSRF non valido.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (strlen($username) < 3 || strlen($password) < 6) {
            $error = 'Username o password non validi.';
        } else {
            $stmt = $mysqli->prepare('SELECT id, password, role FROM account WHERE username = ?');
            if ($stmt) {
                $stmt->bind_param('s', $username);
                $stmt->execute();
                $stmt->store_result();

                if ($stmt->num_rows === 1) {
                    $stmt->bind_result($user_id, $password_hash, $role);
                    $stmt->fetch();

                    if (password_verify($password, $password_hash)) {
                        // Login ok
                        $_SESSION['token']    = bin2hex(random_bytes(16));
                        $_SESSION['user_id']  = $user_id;
                        $_SESSION['username'] = $username;
                        $_SESSION['role']     = $role;

                        header('Location: /RoadPulse/Main/Homepage.php');
                        exit;
                    } else {
                        $error = 'Credenziali errate.';
                    }
                } else {
                    $error = 'Credenziali errate.';
                }

                $stmt->close();
            } else {
                $error = 'Errore interno, riprova più tardi.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Road Pulse - Login</title>
    <link rel="stylesheet" href="/RoadPulse/styles/styles_login.css">
</head>
<body>
    <div class="login-container">
        <img src="../styles/img/logo_Road_Pulse.png" alt="Road Pulse Logo" class="logo-image">

        <h2>Login</h2>

        <?php if (!empty($error)): ?>
            <p class="error-message"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form method="post" autocomplete="off" class="login-form">
            <div class="input-group">
                <input
                    type="text"
                    name="username"
                    placeholder="Inserisci username"
                    required
                    aria-label="Username"
                >
            </div>

            <div class="input-group">
                <input
                    type="password"
                    name="password"
                    placeholder="Inserisci password"
                    required
                    aria-label="Password"
                >
            </div>

            <input type="hidden" name="token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

            <div class="button-group">
                <button type="submit" class="btn btn-login">Accedi</button>
                <a href="signup.php" class="btn btn-registrazione">Registrati</a>
            </div>
        </form>
    </div>
</body>
</html>
