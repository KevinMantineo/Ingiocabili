<?php
require 'db.php';
session_start();

if (isset($_SESSION['token'])) {
    header('Location: /Main/Dashboard.php'); 
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);

    if (strlen($username) < 3 || strlen($password) < 6) {
        $error = 'Username o password non validi.';
    } else {
        $stmt = $mysqli->prepare('SELECT ID, password FROM account WHERE username = ?');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows === 1) {
            $stmt->bind_result($user_id, $password_hash);
            $stmt->fetch();
            if (password_verify($password, $password_hash)) {
                $token = generateToken();
                $_SESSION['token'] = $token;
                $_SESSION['username'] = $username;
                if ($remember) {
                    setcookie('remember_me', $token, time() + 60*60*24*30, '/', '', false, true);
                }
                header('Location: /Main/Dashboard.php');
                exit;
            } else {
                $error = 'Credenziali errate.';
            }
        } else {
            $error = 'Credenziali errate.';
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <meta charset="UTF-8">
</head>
<body>
    <h2>Login</h2>
    <?php if (!empty($error)) echo '<p style="color:red">' . e($error) . '</p>'; ?>
    <form method="post" autocomplete="off">
        <label>Username:<br><input type="text" name="username" required></label><br>
        <label>Password:<br><input type="password" name="password" required></label><br>
        <label><input type="checkbox" name="remember"> Ricordami</label><br>
        <button type="submit">Login</button>
    </form>
    <p>Non hai un account? <a href="signup.php">Registrati</a></p>
</body>
</html>
