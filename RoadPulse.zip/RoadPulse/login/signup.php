<?php
require '../db.php';
session_start();

$mysqli = new mysqli($servername, $username, $password, $dbname);

if ($mysqli->connect_error) {
    die('Errore di connessione al database');
}

// CSRF token
if (!isset($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(16));
}

$error = '';
$userName  = '';
$Email     = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['csrf_token']) {
        $error = 'Token CSRF non valido.';
    } else {
        $Email        = trim($_POST['email'] ?? '');
        $userName     = trim($_POST['username'] ?? '');
        $password     = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Email non valida.';
        } elseif (strlen($userName) < 3) {
            $error = 'Username troppo corto (minimo 3 caratteri).';
        } elseif (strlen($password) < 6) {
            $error = 'Password troppo corta (minimo 6 caratteri).';
        } elseif (!preg_match('/[A-Z]/', $password)) {
            $error = 'La password deve contenere almeno una lettera maiuscola.';
        } elseif (!preg_match('/[0-9]/', $password)) {
            $error = 'La password deve contenere almeno un numero.';
        } elseif ($password !== $confirm_password) {
            $error = 'Le password non coincidono.';
        } else {

            $stmt = $mysqli->prepare('SELECT ID FROM account WHERE email = ? OR username = ?');
            $stmt->bind_param('ss', $Email, $userName);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $error = 'Email o username già registrati.';
            } else {
                $password_hash = password_hash($password, PASSWORD_DEFAULT);

                $stmt_insert = $mysqli->prepare('INSERT INTO account (email, username, password) VALUES (?, ?, ?)');
                $stmt_insert->bind_param('sss', $Email, $userName, $password_hash);
                $stmt_insert->execute();
                $stmt_insert->close();

                header('Location: login.php');
                exit;
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Road Pulse - Registrazione</title>
    <link rel="stylesheet" href="/RoadPulse/styles/styles_login.css">
</head>

<body>

    <div class="login-container">

        <h2>Register</h2>

        <?php if (!empty($error)): ?>
            <p class="error-message"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form class="login-form" method="post" autocomplete="off">

            <div class="input-group">
                <input
                    type="text"
                    name="username"
                    placeholder="Inserisci username"
                    value="<?= htmlspecialchars($userName) ?>"
                    required
                >
            </div>

            <div class="input-group">
                <input
                    type="email"
                    name="email"
                    placeholder="Inserisci email"
                    value="<?= htmlspecialchars($Email) ?>"
                    required
                >
            </div>

            <div class="input-group">
                <input
                    type="password"
                    name="password"
                    placeholder="Inserisci password"
                    required
                >
            </div>

            <div class="input-group">
                <input
                    type="password"
                    name="confirm_password"
                    placeholder="Conferma password"
                    required
                >
            </div>

            <input type="hidden" name="token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

            <button class="btn btn-login" type="submit">Registrati</button>
        </form>

        <p style="color:white; font-size:0.9rem;">
            Hai già un account?
            <a href="login.php" style="color:var(--accent); text-decoration:none; font-weight:600;">Accedi qui</a>
        </p>
    </div>

</body>
</html>
