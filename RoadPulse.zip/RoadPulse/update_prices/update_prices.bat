@echo off
C:\xampp\php\php.exe C:\xampp\htdocs\RoadPulse\update_prices\auto_update_prices.php