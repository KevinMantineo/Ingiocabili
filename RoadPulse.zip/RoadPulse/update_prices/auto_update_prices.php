<?php
require_once 'db.php';

$url_prezzi = 'https://www.mimit.gov.it/images/exportCSV/prezzo_alle_8.csv';

try {
    $csv_content = file_get_contents($url_prezzi);
    
    if ($csv_content === false) {
        die("Errore: impossibile scaricare i dati");
    }

    $temp_file = tempnam(sys_get_temp_dir(), 'prezzi_');
    file_put_contents($temp_file, $csv_content);
    
    $stmt = $conn->prepare("
        INSERT INTO prezzo_alle_8 (idImpianto, descCarburante, prezzo, isSelf, dtComu) 
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            prezzo = VALUES(prezzo),
            isSelf = VALUES(isSelf),
            dtComu = VALUES(dtComu)
    ");
    
    $handle = fopen($temp_file, 'r');
    
    fgetcsv($handle, 0, ';');
    
    $count = 0;
    
    while (($row = fgetcsv($handle, 0, ';')) !== FALSE) {
        if (count($row) >= 4) {
            $idImpianto = intval($row[0]);
            $descCarburante = trim($row[1]);
            $prezzo = floatval(str_replace(',', '.', $row[2]));
            $isSelf = intval($row[3]);
            
            if ($idImpianto > 0 && $descCarburante && $prezzo > 0) {
                $stmt->bind_param("issis", $idImpianto, $descCarburante, $prezzo, $isSelf, date('d/m/Y H:i:s'));
                $stmt->execute();
                $count++;
            }
        }
    }
    
    fclose($handle);
    unlink($temp_file);
    $stmt->close();
    
    echo "Aggiornamento completato: $count prezzi aggiornati";
    
} catch (Exception $e) {
    echo "Errore: " . $e->getMessage();
}

$conn->close();
?>