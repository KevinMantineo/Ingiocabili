<?php
require_once("../db.php");
session_start();

$street_id = isset($_GET['street_id']) ? intval($_GET['street_id']) : ($_POST['street_id'] ?? 0);
$user_id = $_SESSION['user_id'] ?? null;
$username = $_SESSION['username'] ?? 'Anonymous';
$user_role = $_SESSION['role'] ?? 'USER';

// --- ELIMINAZIONE COMMENTO ---
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['delete_comment_id']) &&
    $user_id
) {
    $delete_id = intval($_POST['delete_comment_id']);
    $delete_stmt = $conn->prepare("SELECT id_user FROM review WHERE id = ?");
    $delete_stmt->bind_param("i", $delete_id);
    $delete_stmt->execute();
    $delete_stmt->bind_result($owner_id);
    $delete_stmt->fetch();
    $delete_stmt->close();

    // Solo autore, MODERATOR o ADMIN possono eliminare
    if ($owner_id == $user_id || $user_role === 'ADMIN' || $user_role === 'MODERATOR') {
        $del = $conn->prepare("DELETE FROM review WHERE id = ?");
        $del->bind_param("i", $delete_id);
        $del->execute();
        $del->close();
        
        // Ritorna successo per AJAX
        if (isset($_POST['ajax'])) {
            echo "SUCCESS";
            exit;
        }
    } else {
        if (isset($_POST['ajax'])) {
            echo "ERROR: Permesso negato";
            exit;
        }
    }
}


$experience_options = [];
$res = $conn->query("SHOW COLUMNS FROM review LIKE 'experience'");
if ($row = $res->fetch_assoc()) {
    if (preg_match("/^enum\((.*)\)$/", $row['Type'], $matches)) {
        $vals = str_getcsv($matches[1], ',', "'");
        $experience_options = $vals;
    }
}

// Inserisci un nuovo commento
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    $user_id &&
    isset($_POST['message'], $_POST['street_id'], $_POST['star'], $_POST['experience'])
) {
    $msg = trim($_POST['message']);
    $star = in_array($_POST['star'], ['1','2','3','4','5']) ? $_POST['star'] : '3';
    $experience = in_array($_POST['experience'], $experience_options) ? $_POST['experience'] : '';
    
    if ($msg !== '') {
        $stmt = $conn->prepare("INSERT INTO review (id_user, message, date, id_street, sending_message, delete_message, star, experience) VALUES (?, ?, NOW(), ?, 'PUBLISHED', 0, ?, ?)");
        $stmt->bind_param("isiss", $user_id, $msg, $street_id, $star, $experience);
        $stmt->execute();
        $stmt->close();
        
        // Ritorna successo per AJAX
        if (isset($_POST['ajax'])) {
            echo "SUCCESS";
            exit;
        }
    }
}

// Prende gli ultimi 20 commenti delle strade
$stmt = $conn->prepare(
    "SELECT r.id, r.id_user, r.message, r.date, a.username, r.star, r.experience
     FROM review r
     LEFT JOIN account a ON r.id_user = a.id
     WHERE r.id_street = ? AND (r.sending_message='PUBLISHED' OR r.sending_message='') AND (r.delete_message IS NULL OR r.delete_message=0)
     ORDER BY r.date DESC LIMIT 20"
);
$stmt->bind_param("i", $street_id);
$stmt->execute();
$stmt->bind_result($comment_id, $comment_user_id, $msg, $date, $uname, $star, $experience);

$comments = [];
while ($stmt->fetch()) {
    $comments[] = [
        'id' => $comment_id,
        'id_user' => $comment_user_id,
        'message' => $msg,
        'date' => $date,
        'username' => $uname ?: 'Anonymous',
        'star' => $star,
        'experience' => $experience
    ];
}
$stmt->close();
?>

<div id="comments-list">
    <?php if (empty($comments)): ?>
        <div style="text-align:center; padding:30px; color:var(--text-muted);">
            <em>Ancora nessun commento per questo percorso.</em>
        </div>
    <?php else: ?>
        <?php foreach ($comments as $c): ?>
            <div class="comment-item" data-comment-id="<?= $c['id'] ?>">
                <div class="comment-header">
                    <strong><?= htmlspecialchars($c['username']) ?></strong>
                    <span class="comment-date"><?= htmlspecialchars($c['date']) ?></span>
                </div>
                <div class="comment-meta">
                    <span class="star-rating">
                        <?php for ($i=1; $i<=5; $i++): ?>
                            <?= $i <= intval($c['star']) ? '★' : '☆' ?>
                        <?php endfor; ?>
                    </span>
                    <?php if (!empty($c['experience'])): ?>
                        <span class="comment-experience">
                            <b>Tip:</b> <?= htmlspecialchars($c['experience']) ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="comment-text">
                    <?= nl2br(htmlspecialchars($c['message'])) ?>
                    <?php if (
                        $user_id && 
                        (
                            $user_id == $c['id_user'] ||
                            $user_role === 'ADMIN' ||
                            $user_role === 'MODERATOR'
                        )
                    ): ?>
                        <form method="post" class="delete-comment-form">
                            <input type="hidden" name="delete_comment_id" value="<?= $c['id'] ?>">
                            <input type="hidden" name="street_id" value="<?= intval($street_id) ?>">
                            <input type="hidden" name="ajax" value="1">
                            <button type="submit" class="delete-comment-btn">Elimina</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php if ($user_id): ?>
<form id="add-comment-form" method="post" autocomplete="off">
    <input type="hidden" name="street_id" value="<?= intval($street_id) ?>">
    <input type="hidden" name="ajax" value="1">
    
    <div class="form-row">
        <div class="form-group">
            <label for="star">Valutazione:</label>
            <select name="star" id="star" required>
                <?php for ($i=1; $i<=5; $i++): ?>
                    <option value="<?= $i ?>"><?= $i ?> stella<?= $i>1?'':'' ?></option>
                <?php endfor; ?>
            </select>
        </div>
        
        <div class="form-group">
            <label for="experience">Consiglio:</label>
            <select name="experience" id="experience" required>
                <option value="">Seleziona consiglio</option>
                <?php foreach ($experience_options as $opt): ?>
                    <option value="<?= htmlspecialchars($opt) ?>"><?= htmlspecialchars($opt) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    
    <div class="form-group">
        <textarea name="message" rows="3" maxlength="300" placeholder="Scrivi il tuo commento..." required></textarea>
    </div>
    
    <button type="submit" class="submit-comment-btn">Invia commento</button>
</form>
<?php else: ?>
    <div class="login-prompt">
        <em>Devi essere loggato per commentare.</em>
    </div>
<?php endif; ?>