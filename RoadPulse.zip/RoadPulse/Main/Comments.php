<?php
require_once("../db.php");
session_start();

$street_id = isset($_GET['street_id']) ? intval($_GET['street_id']) : ($_POST['street_id'] ?? 0);
$user_id = $_SESSION['user_id'] ?? null;
$username = $_SESSION['username'] ?? 'Anonymous';
$user_role = $_SESSION['role'] ?? 'USER';

// --- ELIMINAZIONE COMMENTO (PRIMA DI TUTTO) ---
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['delete_comment_id']) &&
    $user_id
) {
    $delete_id = intval($_POST['delete_comment_id']);
    $delete_stmt = $conn->prepare("SELECT id_user FROM review WHERE id = ?");
    $delete_stmt->bind_param("i", $delete_id);
    $delete_stmt->execute();
    $delete_stmt->bind_result($owner_id);
    $delete_stmt->fetch();
    $delete_stmt->close();

    // Solo autore, MODERATOR o ADMIN possono eliminare
    if ($owner_id == $user_id || $user_role === 'ADMIN' || $user_role === 'MODERATOR') {
        $del = $conn->prepare("DELETE FROM review WHERE id = ?");
        $del->bind_param("i", $delete_id);
        $del->execute();
        $del->close();
    }
}

// Get possible values for experience from the table structure
$experience_options = [];
$res = $conn->query("SHOW COLUMNS FROM review LIKE 'experience'");
if ($row = $res->fetch_assoc()) {
    if (preg_match("/^enum\((.*)\)$/", $row['Type'], $matches)) {
        $vals = str_getcsv($matches[1], ',', "'");
        $experience_options = $vals;
    }
}

// Insert new comment
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    $user_id &&
    isset($_POST['message'], $_POST['street_id'], $_POST['star'], $_POST['experience'])
) {
    $msg = trim($_POST['message']);
    $star = in_array($_POST['star'], ['1','2','3','4','5']) ? intval($_POST['star']) : 3;
    $experience = in_array($_POST['experience'], $experience_options) ? $_POST['experience'] : '';
    if ($msg !== '') {
        $stmt = $conn->prepare("INSERT INTO review (id_user, message, date, id_street, sending_message, delete_message, star, experience) VALUES (?, ?, NOW(), ?, 'PUBLISHED', 0, ?, ?)");
        $stmt->bind_param("isiss", $user_id, $msg, $street_id, $star, $experience);
        $stmt->execute();
        $stmt->close();
    }
}

// Get last 20 comments for the route, including star and experience
$stmt = $conn->prepare(
    "SELECT r.id, r.id_user, r.message, r.date, a.username, r.star, r.experience
     FROM review r
     LEFT JOIN account a ON r.id_user = a.id
     WHERE r.id_street = ? AND (r.sending_message='PUBLISHED' OR r.sending_message='') AND (r.delete_message IS NULL OR r.delete_message=0)
     ORDER BY r.date DESC LIMIT 20"
);
$stmt->bind_param("i", $street_id);
$stmt->execute();
$stmt->bind_result($comment_id, $comment_user_id, $msg, $date, $uname, $star, $experience);

$comments = [];
while ($stmt->fetch()) {
    $comments[] = [
        'id' => $comment_id,
        'id_user' => $comment_user_id,
        'message' => $msg,
        'date' => $date,
        'username' => $uname ?: 'Anonymous',
        'star' => $star,
        'experience' => $experience
    ];
}
$stmt->close();
?>

<div style="max-height:300px; overflow-y:auto; margin-bottom:15px;">
    <?php if (empty($comments)): ?>
        <em>No comments yet for this route.</em>
    <?php else: ?>
        <?php foreach ($comments as $c): ?>
            <div style="border-bottom:1px solid #eee; margin-bottom:8px; padding-bottom:6px;">
                <strong><?= htmlspecialchars($c['username']) ?></strong>
                <span style="color:#888; font-size:12px;"><?= htmlspecialchars($c['date']) ?></span>
                <div>
                    <span>
                        <?php for ($i=1; $i<=5; $i++): ?>
                            <?= $i <= intval($c['star']) ? '★' : '☆' ?>
                        <?php endfor; ?>
                    </span>
                    <?php if (!empty($c['experience'])): ?>
                        <span style="margin-left:10px; color:#007bff; font-size:13px;">
                            <b>Tip:</b> <?= htmlspecialchars($c['experience']) ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div><?= nl2br(htmlspecialchars($c['message'])) ?>
                    <?php if (
                        $user_id && 
                        (
                            $user_id == $c['id_user'] ||
                            $user_role === 'ADMIN' ||
                            $user_role === 'MODERATOR'
                        )
                    ): ?>
                        <form method="post" class="delete-comment-form" style="display:inline;">
                            <input type="hidden" name="delete_comment_id" value="<?= $c['id'] ?>">
                            <input type="hidden" name="street_id" value="<?= intval($street_id) ?>">
                            <button type="submit" style="color:red; margin-left:10px;">Elimina</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php if ($user_id): ?>
<form id="add-comment-form" method="post" autocomplete="off">
    <input type="hidden" name="street_id" value="<?= intval($street_id) ?>">
    <label for="star">Rating:</label>
    <select name="star" id="star" required>
        <?php for ($i=1; $i<=5; $i++): ?>
            <option value="<?= $i ?>"><?= $i ?> star<?= $i>1?'s':'' ?></option>
        <?php endfor; ?>
    </select>
    <label for="experience">Tip:</label>
    <select name="experience" id="experience" required>
        <option value="">Select tip</option>
        <?php foreach ($experience_options as $opt): ?>
            <option value="<?= htmlspecialchars($opt) ?>"><?= htmlspecialchars($opt) ?></option>
        <?php endforeach; ?>
    </select>
    <textarea name="message" rows="2" style="width:100%;" maxlength="300" placeholder="Write a comment..." required></textarea>
    <button type="submit" style="margin-top:5px;">Send</button>
</form>
<?php else: ?>
    <em>You must be logged in to comment.</em>
<?php endif; ?>
