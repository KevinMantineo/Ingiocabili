<?php
session_start();
require '../db.php';

/* =======================================================
   FUNZIONE DISTANZA HAVERSINE
======================================================= */
function haversine($lat1, $lon1, $lat2, $lon2) {
    if (!is_numeric($lat1) || !is_numeric($lon1) ||
        !is_numeric($lat2) || !is_numeric($lon2)) {
        return 999999;
    }

    $R = 6371;
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);

    $a = sin($dLat / 2) ** 2 +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon / 2) ** 2;

    return $R * 2 * atan2(sqrt($a), sqrt(1 - $a));
}


/* =======================================================
   AJAX PREZZI POMPE
======================================================= */
if (isset($_GET['ajax']) && $_GET['ajax'] === "pump_prices") {
    $id = intval($_GET['id']);

    $q = $conn->query("SELECT descCarburante, prezzo, isSelf 
                       FROM prezzo_alle_8 
                       WHERE idImpianto = $id");

    $output = [];
    while ($r = $q->fetch_assoc()) $output[] = $r;

    header("Content-Type: application/json");
    echo json_encode($output);
    exit;
}

/* =======================================================
   RECUPERO PERCORSO
======================================================= */
$route_id = isset($_GET['route_id']) ? intval($_GET['route_id']) : 0;

$stmt = $conn->prepare("SELECT * FROM street WHERE id = ? AND status = 'approved'");
$stmt->bind_param("i", $route_id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

if (!$row) {
    echo "<script>alert('Percorso non trovato');location.href='Homepage.php';</script>";
    exit;
}

$city_start  = $row['city_start'];
$city_end    = $row['city_end'];
$description = $row['description'];

/* =======================================================
   MOTO DA SESSIONE
======================================================= */
$bike_brand = $_SESSION['brand'] ?? null;
$bike_model = $_SESSION['model'] ?? null;
$bike_km_l  = null;

if ($bike_brand && $bike_model) {
    $s2 = $conn->prepare("SELECT km_l FROM motorbike WHERE brand = ? AND model = ? LIMIT 1");
    $s2->bind_param("ss", $bike_brand, $bike_model);
    $s2->execute();
    $s2->bind_result($kmdb);
    if ($s2->fetch()) $bike_km_l = $kmdb !== null ? floatval($kmdb) : null;
    $s2->close();
}

/* =======================================================
   WAYPOINTS
======================================================= */
$route_points = [];

$clean = function($v) {
    if (!$v) return null;
    $v = trim($v);
    if ($v === "" || stripos($v, "null") !== false) return null;
    return $v;
};

$addWp = function($c) use (&$route_points, $clean) {
    $c = $clean($c);
    if (!$c) return;

    $p = explode(",", $c);
    if (count($p) != 2) return;

    $lat = floatval($p[0]);
    $lng = floatval($p[1]);

    if ($lat == 0 || $lng == 0) return;

    $route_points[] = ["lat" => $lat, "lng" => $lng];
};

$addWp($row['coo_start']);
foreach (['point1','point2','point3','point4','point5','point6','point7','point8','point9','point10'] as $pname)
    $addWp($row[$pname]);
$addWp($row['coo_end']);

/* =======================================================
   POMPE VICINO
======================================================= */
$pumps = [];

$q = $conn->query("SELECT idImpianto, Gestore, Bandiera, `Nome Impianto`, Latitudine, Longitudine 
                   FROM anagrafica_impianti_attivi__1_");

while ($p = $q->fetch_assoc()) {
    $plat = floatval($p['Latitudine']);
    $plng = floatval($p['Longitudine']);

    foreach ($route_points as $pt) {
        if (haversine($pt['lat'], $pt['lng'], $plat, $plng) <= 4) {
            $pumps[] = [
                "idImpianto" => $p['idImpianto'],
                "nome"       => $p['Nome Impianto'],
                "gestore"    => $p['Gestore'],
                "bandiera"   => $p['Bandiera'],
                "lat"        => $plat,
                "lng"        => $plng
            ];
            break;
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<title>Percorso <?= htmlspecialchars($city_start) ?> → <?= htmlspecialchars($city_end) ?></title>
<link rel="stylesheet" href="../styles/dashboard.css">

<script>
const userWaypoints = <?= json_encode($route_points) ?>;
const pumps         = <?= json_encode($pumps) ?>;
const bikeBrand     = <?= json_encode($bike_brand) ?>;
const bikeModel     = <?= json_encode($bike_model) ?>;
const bikeKmL       = <?= json_encode($bike_km_l) ?>;

function shareRoute() {
    const url = window.location.href;
    const title = "Guarda questo percorso su RoadPulse!";

    // Supporto Web Share API (mobile + PC moderni)
    if (navigator.share) {
        navigator.share({
            title: title,
            text: "Dai un’occhiata a questo percorso!",
            url: url
        }).catch(err => console.log("Condivisione annullata:", err));
        return;
    }

    // FALLBACK: popup social
    const encoded = encodeURIComponent(url);

    const shareOptions = `
        <div style="text-align:center;">
            <h3 style="margin-bottom:10px;">Condividi il percorso</h3>
            <a href="https://wa.me/?text=${encoded}" target="_blank">WhatsApp</a><br>
            <a href="https://t.me/share/url?url=${encoded}" target="_blank">Telegram</a><br>
            <a href="https://www.facebook.com/sharer/sharer.php?u=${encoded}" target="_blank">Facebook</a><br>
            <a href="https://twitter.com/intent/tweet?url=${encoded}" target="_blank">X (Twitter)</a><br><br>
            <button onclick="copyLink()" style="
                background:#ffbb00;
                padding:8px 16px;
                border:none;
                border-radius:10px;
                cursor:pointer;
                font-weight:600;">
                Copia link
            </button>
        </div>
    `;

    const win = window.open("", "_blank", "width=350,height=500");
    win.document.write(shareOptions);
}

function copyLink() {
    navigator.clipboard.writeText(window.location.href);
    alert("Link copiato!");
}

let routeDistanceKm = null;

/* =======================================================
   MAPPA
======================================================= */
function initMap() {
    const mapDiv = document.getElementById("map");

    if (!userWaypoints || userWaypoints.length < 2) {
        mapDiv.innerHTML = "<em>Percorso non disponibile</em>";
        return;
    }

    const map = new google.maps.Map(mapDiv, {
        center: userWaypoints[0],
        zoom: 12
    });

    new google.maps.Marker({ position: userWaypoints[0], map, label: "A" });
    new google.maps.Marker({ position: userWaypoints[userWaypoints.length-1], map, label: "B" });

    const ds = new google.maps.DirectionsService();
    const dr = new google.maps.DirectionsRenderer({ map, suppressMarkers: true });

    ds.route({
        origin: userWaypoints[0],
        destination: userWaypoints[userWaypoints.length - 1],
        waypoints: userWaypoints.slice(1,-1).map(x => ({location:x, stopover:false})),
        travelMode: "DRIVING"
    }, (res, status) => {

        if (status === "OK") {

            dr.setDirections(res);

            let meters = 0;
            res.routes[0].legs.forEach(l => meters += l.distance.value);
            routeDistanceKm = meters / 1000;

            document.getElementById("route-distance").textContent =
                routeDistanceKm.toFixed(1) + " km";
        }

        pumps.forEach(p => {
            const m = new google.maps.Marker({
                map,
                position: {lat:p.lat, lng:p.lng},
                icon: "https://maps.google.com/mapfiles/ms/icons/gas.png"
            });

            m.addListener("click", () => {
                fetch("Dashboard.php?ajax=pump_prices&id=" + p.idImpianto)
                    .then(r=>r.json())
                    .then(data=>showPumpDetails(p,data));

            });
        });

    });
}
window.initMap = initMap;

/* =======================================================
   DETTAGLI POMPA
======================================================= */
function showPumpDetails(p, data) {
    let html = `<h3>${p.nome}</h3>
        <p><strong>Gestore:</strong> ${p.gestore} — <strong>Bandiera:</strong> ${p.bandiera}</p>`;

    if (routeDistanceKm && bikeKmL)
        html += `<p class="pump-trip-info">
                    <strong>Tragitto:</strong> ${routeDistanceKm.toFixed(1)} km • 
                    <strong>Moto:</strong> ${bikeBrand} ${bikeModel} (${bikeKmL} km/l)
                 </p>`;

    html += `
    <table class="pump-table">
        <tr>
            <th>Carburante</th><th>Prezzo</th><th>Tipo</th><th>Spesa</th>
        </tr>`;

    if (!data.length) {
        html += `<tr><td colspan="4"><em>Nessun dato disponibile</em></td></tr>`;
    } else {
        data.forEach(r => {
            const price = parseFloat(r.prezzo);
            let cost = "-";

            if (routeDistanceKm && bikeKmL && price > 0) {
                const liters = routeDistanceKm / bikeKmL;
                cost = "€" + (liters * price).toFixed(2);
            }

            html += `
            <tr>
                <td>${r.descCarburante}</td>
                <td>€${r.prezzo}</td>
                <td>${r.isSelf == 1 ? "Self" : "Servito"}</td>
                <td>${cost}</td>
            </tr>`;
        });
    }

    html += `</table>`;
    document.getElementById("pump-details").innerHTML = html;
}

/* =======================================================
   METEO ORARIO 
======================================================= */
document.addEventListener("DOMContentLoaded", () => {
    const city   = <?= json_encode($city_start) ?>;
    const apiKey = "7616323a45af9153f421313a7f4ae1d1";

    const targetHours = ["06:00","09:00","12:00","15:00","18:00","21:00"];

    fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=metric&lang=it`)
        .then(r=>r.json())
        .then(d => {

            const box = document.getElementById("weather-hourly");

            if (!d || !Array.isArray(d.list)) {
                box.innerHTML = "<em>Nessun dato meteo</em>";
                return;
            }

            const selected=[];
            targetHours.forEach(h=>{
                let f=d.list.find(x=>x.dt_txt.endsWith(h+":00"));
                if(f) selected.push(f);
            });

            if(!selected.length){
                box.innerHTML="<em>Nessuna previsione</em>";
                return;
            }

            let html=`<div class="weather-row">`;

            selected.forEach(f=>{
                const t=f.dt_txt.split(" ")[1].slice(0,5);
                const temp=Math.round(f.main.temp);
                const desc=f.weather[0].description;
                const ic=f.weather[0].icon;

                html+=`
                <div class="weather-item">
                    <div class="weather-time">${t}</div>
                    <img src="https://openweathermap.org/img/wn/${ic}.png">
                    <div class="weather-temp">${temp}°C</div>
                    <div class="weather-desc">${desc}</div>
                </div>`;
            });

            html+=`</div>`;
            box.innerHTML=html;
        });
});

/* =======================================================
   MODALE COMMENTI 
======================================================= */
function openCommentsModal() {
    const modal = document.getElementById("comments-modal");
    const content = document.getElementById("comments-content");
    
    // Mostra la modale
    modal.style.display = "flex";
    
    // Carica i commenti via AJAX
    loadComments();
}

function closeCommentsModal() {
    document.getElementById("comments-modal").style.display = "none";
}

function loadComments() {
    const content = document.getElementById("comments-content");
    content.innerHTML = '<div style="text-align:center; padding:20px;"><em>Caricamento commenti...</em></div>';
    
    fetch(`Comments.php?street_id=<?= $route_id ?>`)
        .then(response => {
            if (!response.ok) throw new Error('Network error');
            return response.text();
        })
        .then(html => {
            content.innerHTML = html;
            attachCommentEvents();
        })
        .catch(err => {
            console.error('Errore caricamento commenti:', err);
            content.innerHTML = '<div style="text-align:center; color:#ff6b6b; padding:20px;">Errore nel caricamento dei commenti</div>';
        });
}

function attachCommentEvents() {
    // Gestione submit form nuovo commento
    const form = document.getElementById('add-comment-form');
    if (form) {
        form.onsubmit = function(e) {
            e.preventDefault();
            submitCommentForm(this);
        };
    }
    
    // Gestione eliminazione commenti
    const deleteForms = document.querySelectorAll('.delete-comment-form');
    deleteForms.forEach(form => {
        form.onsubmit = function(e) {
            e.preventDefault();
            deleteComment(this);
        };
    });
}

function submitCommentForm(form) {
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    
    // Disabilita bottone durante l'invio
    submitBtn.disabled = true;
    submitBtn.textContent = 'Invio in corso...';
    
    const formData = new FormData(form);
    
    fetch('Comments.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        if (result === "SUCCESS") {
            // Ricarica i commenti
            loadComments();
            // Reset del form
            form.reset();
        } else {
            alert("Errore nell'invio del commento: " + result);
        }
    })
    .catch(err => {
        console.error('Errore invio commento:', err);
        alert("Errore di connessione durante l'invio del commento");
    })
    .finally(() => {
        // Riabilita bottone
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
    });
}

function deleteComment(form) {
    if (!confirm('Sei sicuro di voler eliminare questo commento?')) {
        return;
    }
    
    const formData = new FormData(form);
    
    fetch('Comments.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        if (result === "SUCCESS") {
            // Ricarica i commenti
            loadComments();
        } else {
            alert("Errore nell'eliminazione del commento: " + result);
        }
    })
    .catch(err => {
        console.error('Errore eliminazione commento:', err);
        alert("Errore di connessione durante l'eliminazione");
    });
}

// Chiudi la modale cliccando fuori dal contenuto
document.getElementById('comments-modal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeCommentsModal();
    }
});

// Chiudi con ESC
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeCommentsModal();
    }
});

</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB_cEu5Bqsuvs4b1kWBP4vxZdU1vZJOlNI&callback=initMap" async defer></script>
</head>
<body>

<div class="dashboard-container">

    <h1>Percorso: <?= htmlspecialchars($city_start) ?> → <?= htmlspecialchars($city_end) ?></h1>

    <div class="route-desc">
        <p class="route-text"><strong>Descrizione:</strong> <?= nl2br(htmlspecialchars($description ?: "Nessuna descrizione")) ?></p>
        <p class="route-distance"><strong>Distanza totale:</strong> <span id="route-distance">Calcolo...</span></p>

        <?php if ($bike_brand && $bike_model && $bike_km_l): ?>
        <p class="bike-info"><strong>Moto:</strong> <?= $bike_brand ?> <?= $bike_model ?> (<?= $bike_km_l ?> km/l)</p>
        <?php endif; ?>
    </div>

    <div id="map"></div>

    <div style="height:20px;"></div>

    <div class="action-buttons">
        <a class="back-link" href="Homepage.php">⟵ Torna alla Homepage</a>
        <button class="comments-btn" onclick="openCommentsModal()">💬 Commenti</button>
        <button class="share-btn" onclick="shareRoute()">📤 Condividi</button>
    </div>

    <div id="pump-details"></div>

    <div class="weather-box">
        <h2>Previsioni orarie di oggi</h2>
        <div id="weather-hourly"><em>Caricamento...</em></div>
    </div>

</div>

<!-- MODALE COMMENTI -->
<div id="comments-modal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>💬 Commenti del percorso</h3>
            <span class="close-modal" onclick="closeCommentsModal()">&times;</span>
        </div>
        <div class="modal-body" id="comments-content">
            <em>Caricamento commenti...</em>
        </div>
    </div>
</div>

</body>
</html>