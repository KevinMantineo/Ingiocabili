<?php
require '../db.php';
session_start();

// --- AJAX: restituisci i prezzi se richiesto ---
if (isset($_GET['ajax']) && $_GET['ajax'] === 'pump_prices' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $res = $conn->query("SELECT descCarburante, prezzo, isSelf FROM prezzo_alle_8 WHERE idimpianto = $id");
    $prezzi = [];
    while ($row = $res->fetch_assoc()) $prezzi[] = $row;
    header('Content-Type: application/json');
    echo json_encode($prezzi);
    exit;
}

// Recupera la tratta selezionata tramite GET, default 1
$street_id = isset($_GET['street_id']) ? intval($_GET['street_id']) : 1;

// Recupera la tratta selezionata dal database
$stmt = $conn->prepare("SELECT city_start, city_end, coo_start, coo_end, point1, point2, point3, point4, point5, point6, point7, point8, point9, point10, description FROM street WHERE id = ?");
$stmt->bind_param("i", $street_id);
$stmt->execute();
$stmt->bind_result($city_start, $city_end, $coo_start, $coo_end, $point1, $point2, $point3, $point4, $point5, $point6, $point7, $point8, $point9, $point10, $description);
$stmt->fetch();
$stmt->close();

// Funzione per convertire stringa coordinate in array lat/lng
function parseCoo($coo) {
    if (!$coo) return null;
    $parts = explode(',', $coo);
    if (count($parts) != 2) return null;
    return [
        'lat' => floatval(trim($parts[0])),
        'lng' => floatval(trim($parts[1]))
    ];
}

// Ottieni coordinate di partenza e arrivo dalle colonne coo_start e coo_and
$startCoo = parseCoo($coo_start); // coordinate city_start
$endCoo = parseCoo($coo_end);     // coordinate city_end

// Ottieni tutti i waypoints intermedi (se presenti)
$waypoints = [];
foreach ([$point1, $point2, $point3, $point4, $point5, $point6, $point7, $point8, $point9, $point10] as $pt) {
    if ($pt && strpos($pt, ',') !== false) {
        $wp = parseCoo($pt);
        if ($wp) $waypoints[] = $wp;
    }
}

// Funzione per calcolare la distanza approssimativa (in km) tra due coordinate
function haversine($lat1, $lon1, $lat2, $lon2) {
    $R = 6371; // raggio della Terra in km
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $a = sin($dLat/2) * sin($dLat/2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon/2) * sin($dLon/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $R * $c;
}

// Recupera tutte le pompe
$pump_query = $conn->query("SELECT idImpianto, Gestore, Bandiera, `Nome Impianto`, Latitudine, Longitudine FROM anagrafica_impianti_attivi__1_");
$pumps = [];
$points = array_merge([$startCoo], $waypoints, [$endCoo]);
$max_distance_km = 4; // distanza massima dalla tratta (modifica a piacere)

while ($row = $pump_query->fetch_assoc()) {
    $lat = floatval($row['Latitudine']);
    $lng = floatval($row['Longitudine']);
    foreach ($points as $pt) {
        if (!$pt) continue;
        $dist = haversine($pt['lat'], $pt['lng'], $lat, $lng);
        if ($dist <= $max_distance_km) {
            $pumps[] = [
                'idImpianto' => $row['idImpianto'], 
                'nome' => $row['Nome Impianto'],
                'gestore' => $row['Gestore'],
                'bandiera' => $row['Bandiera'],
                'lat' => $lat,
                'lng' => $lng
            ];
            break;
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Homepage</title>
    <style>
        #map {
            height: 60vh;
            width: 60%;
        }
    </style>
    <script>
        // Passa le coordinate PHP a JS
        const startCoo = <?php echo json_encode($startCoo); ?>; // city_start
        const endCoo = <?php echo json_encode($endCoo); ?>;     // city_end
        const waypoints = <?php echo json_encode($waypoints); ?>; // punti intermedi
        const pumps = <?php echo json_encode($pumps); ?>;

        function initMap() {
            if (!startCoo || !endCoo) {
                alert("Coordinate mancanti per questo percorso.");
                return;
            }
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 11,
                center: startCoo,
            });

            const directionsService = new google.maps.DirectionsService();
            const directionsRenderer = new google.maps.DirectionsRenderer({ map: map });

            // Imposta stopover: false per non mostrare i waypoints come tappe visibili
            directionsService.route(
                {
                    origin: startCoo,
                    destination: endCoo,
                    waypoints: waypoints.map(wp => ({ location: wp, stopover: false })),
                    travelMode: google.maps.TravelMode.DRIVING,
                },
                (response, status) => {
                    if (status === "OK") {
                        directionsRenderer.setDirections(response);
                    } else {
                        alert("Errore nella richiesta: " + status);
                    }
                }
            );

            // Marker per le pompe di benzina vicine al percorso (city_start, waypoints, city_end)
            pumps.forEach(function(pump) {
                const marker = new google.maps.Marker({
                    position: {lat: pump.lat, lng: pump.lng},
                    map: map,
                    title: pump.nome + " (" + pump.bandiera + ")",
                    icon: "https://maps.google.com/mapfiles/ms/icons/gas.png"
                });

                marker.addListener('click', function() {
                    fetch(`Dashboard.php?ajax=pump_prices&id=${pump.idImpianto}`)
                        .then(res => res.json())
                        .then(data => {
                            let html = `<h3>${pump.nome}</h3>`;
                            html += `<div><strong>Gestore:</strong> ${pump.gestore} <br><strong>Bandiera:</strong> ${pump.bandiera}</div>`;
                            if (data.length === 0) {
                                html += "<em>Nessun prezzo disponibile.</em>";
                            } else {
                                html += "<table border='1' style='border-collapse:collapse;'><tr><th>Carburante</th><th>Prezzo</th><th>Self</th></tr>";
                                data.forEach(prezzo => {
                                    html += `<tr>
                                        <td>${prezzo.descCarburante}</td>
                                        <td>€${prezzo.prezzo}</td>
                                        <td>${prezzo.isSelf == 1 ? "Self" : "Servito"}</td>
                                    </tr>`;
                                });
                                html += "</table>";
                            }
                            const div = document.getElementById("pump-details");
                            div.innerHTML = html;
                            div.style.display = "block";
                        });
                });
            });
        }

        document.addEventListener('DOMContentLoaded', function () {
            // Meteo - Previsione per la giornata di oggi
            const apiKey = "7616323a45af9153f421313a7f4ae1d1";
            // Usa city_start dal PHP
            const city = <?php echo json_encode($city_start); ?> + ",IT";
            const url = `https://api.openweathermap.org/data/2.5/forecast?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric&lang=it`;

            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error("Errore nella richiesta meteo");
                    }
                    return response.json();
                })
                .then(data => {
                    const weatherDiv = document.getElementById("weather");
                    const today = new Date().toISOString().slice(0, 10); // formato YYYY-MM-DD
                    let html = `<table border="1" style="border-collapse:collapse;">
                        <tr>
                            <th>Ora</th>
                            <th>Temp (°C)</th>
                            <th>Condizioni</th>
                            <th>Umidità</th>
                            <th>Icona</th>
                        </tr>`;

                    // Filtra solo le previsioni di oggi
                    data.list.forEach(item => {
                        if (item.dt_txt.startsWith(today)) {
                            const time = item.dt_txt.slice(11, 16);
                            const temp = item.main.temp;
                            const description = item.weather[0].description;
                            const humidity = item.main.humidity;
                            const icon = item.weather[0].icon;
                            html += `
                                <tr>
                                    <td>${time}</td>
                                    <td>${temp}</td>
                                    <td>${description}</td>
                                    <td>${humidity}%</td>
                                    <td><img src="https://openweathermap.org/img/wn/${icon}@2x.png" alt="Icona meteo"></td>
                                </tr>
                            `;
                        }
                    });
                    html += "</table>";
                    weatherDiv.innerHTML = html;
                })
                .catch(error => {
                    console.error(error);
                    document.getElementById("weather").innerText = "Impossibile recuperare il meteo.";
                });
        });
    </script>
    <script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB_cEu5Bqsuvs4b1kWBP4vxZdU1vZJOlNI&callback=initMap&libraries=places"
        async defer>
    </script>
</head>
<body>
    <h1>Route from <?php echo htmlspecialchars($city_start); ?> to <?php echo htmlspecialchars($city_end); ?></h1>
    <div id="map"></div>
    <button type="button" id="open-comments">Comments</button>
    <button type="button" onclick="window.location.href='/RoadPulse/Main/Homepage.php'">Back to Homepage</button>
    <div>
        <?php if (!empty($description)): ?>
            <strong>Description:</strong>
            <div><?= nl2br(htmlspecialchars($description)) ?></div>
        <?php else: ?>
            <em>No description available for this route.</em>
        <?php endif; ?>
    </div>
    <br>
    <div>
        <strong>Selected motorbike:</strong>      
        <?php
            echo htmlspecialchars($_SESSION['brand']) . ' ' . htmlspecialchars($_SESSION['model']);
        ?>
    </div>

    <div id="pump-details" style="display:none; border:1px solid #ccc; padding:10px; margin-top:10px; width:50%;"></div>
    
    <h1>Weather in <?php echo htmlspecialchars($city_start); ?></h1>
    <div id="weather"></div>

    <!-- Dettagli Pompa (visibile solo su click marker) -->
    <div id="pump-details" style="display:none; position:absolute; background:white; border:1px solid #ccc; padding:10px; z-index:1000;"></div>

    <!-- Modal Commenti -->
    <div id="comments-modal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.4); z-index:2000; align-items:center; justify-content:center;">
        <div style="background:#fff; border-radius:8px; max-width:500px; width:90%; margin:auto; margin-top:60px; padding:20px; position:relative;">
            <button id="close-comments-modal" style="position:absolute; top:10px; right:10px; font-size:18px;">&times;</button>
            <div id="comments-content">Caricamento commenti...</div>
        </div>
    </div>
<script>

    document.getElementById('open-comments').onclick = function() {
        document.getElementById('comments-modal').style.display = 'flex';
        loadComments();
    };
    document.getElementById('close-comments-modal').onclick = function() {
        document.getElementById('comments-modal').style.display = 'none';
    };

    function loadComments() {
        fetch('Comments.php?street_id=<?= $street_id ?>')
            .then(res => res.text())
            .then(html => {
                document.getElementById('comments-content').innerHTML = html;
            });
    }

    // Gestione invio nuovo commento via AJAX
    document.addEventListener('submit', function(e) {
        // Invio nuovo commento
        if (e.target && e.target.id === 'add-comment-form') {
            e.preventDefault();
            const form = e.target;
            fetch('Comments.php', {
                method: 'POST',
                body: new FormData(form)
            })
            .then(res => res.text())
            .then(html => {
                document.getElementById('comments-content').innerHTML = html;
            });
        }

        // Invio eliminazione commento via AJAX
        if (e.target && e.target.classList.contains('delete-comment-form')) {
            e.preventDefault();
            const form = e.target;
            fetch('Comments.php', {
                method: 'POST',
                body: new FormData(form)
            })
            .then(res => res.text())
            .then(html => {
                document.getElementById('comments-content').innerHTML = html;
            });
        }
    });
    </script>
</body>
</html>