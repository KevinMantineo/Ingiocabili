<?php
session_start();
require_once("../db.php");

/* AUTH & PROFILO */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: /RoadPulse/login/login.php");
    exit;
}
if (!isset($_SESSION['token'])) {
    header("Location: /RoadPulse/login/login.php");
    exit;
}

$user_id  = $_SESSION['user_id'] ?? null;
$user_role = 'USER';

if ($user_id) {
    $stmt = $conn->prepare("SELECT role,image FROM account WHERE id=?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($role, $blob);
    if ($stmt->fetch()) {
        $_SESSION['role'] = $role;
        $_SESSION['profile_img'] = $blob
            ? "data:image/jpeg;base64," . base64_encode($blob)
            : "img/ProfiloDefault.png";
    }
    $stmt->close();
}

/* CSRF */
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$welcome_message = '';

if (!isset($_SESSION['first_login_done'])) {
    $welcome_message = 'Benvenuto';
    $_SESSION['first_login_done'] = true;
}

/* BRAND / MODELLI */
$brands = [];
$models = [];
$q = $conn->query("SELECT brand,model FROM motorbike");
while ($r = $q->fetch_assoc()) {
    $b = $r['brand'];
    $m = $r['model'];
    if (!in_array($b, $brands)) {
        $brands[] = $b;
    }
    $models[$b][] = $m;
}

/* ROTTE */
$streets = [];
$q = $conn->query("SELECT id,city_start,city_end FROM street WHERE status='approved'");
while ($r = $q->fetch_assoc()) {
    $streets[] = [
        'id'   => $r['id'],
        'name' => htmlspecialchars($r['city_start']) . " - " . htmlspecialchars($r['city_end'])
    ];
}

$conn->close();

/* POST → DASHBOARD */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['logout'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Invalid CSRF token");
    }
    $_SESSION['brand'] = $_POST['brand'];
    $_SESSION['model'] = $_POST['model'];
    header("Location: Dashboard.php?route_id=" . $_POST['street']);
    exit;
}

$imgSrc   = !empty($_SESSION['profile_img']) ? $_SESSION['profile_img'] : 'img/ProfiloDefault.png';
$username = htmlspecialchars($_SESSION['username'] ?? 'User');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Select Motorbike and Route</title>
    <link rel="stylesheet" href="../styles/seleziona_moto.css">
</head>
<body>

<div class="homepage-container">
    <div class="container">
        <!-- HEADER PROFILO -->
        <div class="profile-header">
            <img src="<?= htmlspecialchars($imgSrc) ?>"
                 id="profile-img-thumb"
                 alt="Profile"
                 onclick="showProfileModal()">
            <span><?= $username ?> <?= $welcome_message ?></span>
        </div>

        <!-- BOTTONI PROFILO -->
        <div class="header-actions">
            <form method="post">
                <button type="submit" class="btn btn-secondary" name="logout">Logout</button>
            </form>
            <button type="button"
                    class="btn btn-secondary"
                    onclick="window.location.href='UserProfile.php'">
                Profilo utente
            </button>
        </div>

        <!-- FORM MOTO + ROTTA -->
        <div class="seleziona-moto-container">
            <form method="post" class="seleziona-moto-form" autocomplete="off">
                <div class="seleziona-moto-row">
                    <label class="seleziona-moto-label" for="brand">Motorbike brand:</label>
                    <select name="brand" id="brand" class="seleziona-moto-select" onchange="updateModels()" required>
                        <option value="">Select brand</option>
                        <?php foreach ($brands as $b): ?>
                            <option value="<?= htmlspecialchars($b) ?>"
                                <?= (!empty($_SESSION['brand']) && $_SESSION['brand'] == $b ? 'selected' : '') ?>>
                                <?= htmlspecialchars($b) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="seleziona-moto-row">
                    <label class="seleziona-moto-label" for="model">Motorbike model:</label>
                    <select name="model" id="model" class="seleziona-moto-select" required>
                        <option value="">Select model</option>
                    </select>
                </div>

                <div class="seleziona-moto-row">
                    <label class="seleziona-moto-label" for="street">Route:</label>
                    <select name="street" id="street" class="seleziona-moto-select" required>
                        <option value="">Select route</option>
                        <?php foreach ($streets as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= $s['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">

                <div class="seleziona-moto-actions">
                    <button class="btn btn-primary" type="submit">Submit</button>
                    <button class="btn btn-secondary" type="button" onclick="location.href='addPattern.php'">
                        Aggiungi percorso
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- CAROSELLO NEWS -->
    <div id="news-carousel-container">
        <button id="carousel-prev" class="carousel-arrow">&#8592;</button>
        <div id="news-container"></div>
        <button id="carousel-next" class="carousel-arrow">&#8594;</button>
        <div id="carousel-page-indicator"></div>
    </div>
</div>

<!-- MODAL PROFILO -->
<div id="profile-modal">
    <span id="profile-modal-close" onclick="hideProfileModal()">&times;</span>
    <img src="<?= htmlspecialchars($imgSrc) ?>" id="profile-img-large" alt="Profile large">
</div>

<script>
// --- MODELLI PER BRAND ---
const models = <?= json_encode($models) ?>;

function updateModels() {
    const brand = document.getElementById("brand").value;
    const model = document.getElementById("model");
    model.innerHTML = '<option value="">Select model</option>';

    if (models[brand]) {
        models[brand].forEach(m => {
            const opt = document.createElement("option");
            opt.value = m;
            opt.textContent = m;
            model.appendChild(opt);
        });
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const brandSelect = document.getElementById("brand");
    if (brandSelect.value) {
        updateModels();
        <?php if (!empty($_SESSION['model'])): ?>
        document.getElementById("model").value = "<?= addslashes($_SESSION['model']) ?>";
        <?php endif; ?>
    }
});

// --- MODALE PROFILO ---
function showProfileModal() {
    document.getElementById("profile-modal").style.display = "flex";
}
function hideProfileModal() {
    document.getElementById("profile-modal").style.display = "none";
}

// --- NEWS CAROUSEL ---
let allNews = [];
let currentNewsPage = 1;
const newsPerPage = 3;

async function loadNews() {
    try {
        const res = await fetch("https://api.allorigins.win/raw?url=https://www.moto.it/rss/news.xml");
        const text = await res.text();
        const xml = new DOMParser().parseFromString(text, "application/xml");
        const items = xml.querySelectorAll("item");
        allNews = [];

        items.forEach((it, i) => {
            if (i < 50) {
                allNews.push({
                    title: it.querySelector("title")?.textContent || "",
                    link:  it.querySelector("link")?.textContent  || "#",
                    desc:  it.querySelector("description")?.textContent || "",
                    img:   it.querySelector("enclosure")?.getAttribute("url") || ""
                });
            }
        });

        renderNews(1);
    } catch (e) {
        document.getElementById("news-container").innerHTML = "Errore caricamento news";
    }
}

function renderNews(page) {
    const start = (page - 1) * newsPerPage;
    const data  = allNews.slice(start, start + newsPerPage);
    let html    = "";

    data.forEach(n => {
        html += `
            <div class="news-card">
                <a href="${n.link}" target="_blank">
                    ${n.img ? `<img class="news-card-img" src="${n.img}" alt="">` : ""}
                    <div class="news-card-content">
                        <h3>${n.title}</h3>
                        <p>${n.desc.replace(/<[^>]+>/g, "")}</p>
                    </div>
                </a>
            </div>`;
    });

    document.getElementById("news-container").innerHTML = html;

    currentNewsPage = page;
    const totalPages = Math.ceil(allNews.length / newsPerPage);
    document.getElementById("carousel-page-indicator").textContent =
        totalPages ? `Page ${page} of ${totalPages}` : "";

    document.getElementById("carousel-prev").style.display = (page > 1) ? "flex" : "none";
    document.getElementById("carousel-next").style.display = (page < totalPages) ? "flex" : "none";
}

document.getElementById("carousel-prev").onclick = () => {
    if (currentNewsPage > 1) renderNews(currentNewsPage - 1);
};
document.getElementById("carousel-next").onclick = () => {
    const totalPages = Math.ceil(allNews.length / newsPerPage);
    if (currentNewsPage < totalPages) renderNews(currentNewsPage + 1);
};

loadNews();
</script>

</body>
</html>
