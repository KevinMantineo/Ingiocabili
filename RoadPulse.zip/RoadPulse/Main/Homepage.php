<?php
session_start();
require_once("../db.php");

// Gestione logout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: /RoadPulse/login/login.php");
    exit;
}

if (!isset($_SESSION['token'])) {
    header("Location: /RoadPulse/login/login.php");
    exit;
}

// Recupera il ruolo dell'utente autenticato
$user_id = $_SESSION['user_id'] ?? null;
$user_role = 'USER'; // default

if ($user_id) {
    $stmt = $conn->prepare("SELECT role FROM account WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($role);
    if ($stmt->fetch()) {
        $user_role = $role;
        $_SESSION['role'] = $role; // Salva il ruolo in sessione
    }
    $stmt->close();
}

// Welcome message logic
if (!isset($_SESSION['first_login_done'])) {
    $welcome_message = "Welcome";
    $_SESSION['first_login_done'] = true;
} else {
    $welcome_message = "Welcome back";
}
$username = htmlspecialchars($_SESSION['username'] ?? 'User');

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// Get brands, models, and routes
$brands = [];
$models = [];
$streets = [];

$res = $conn->query("SELECT DISTINCT brand FROM motorbike");
while ($row = $res->fetch_assoc()) {
    $brands[] = htmlspecialchars($row['brand']);
}
$res = $conn->query("SELECT brand, model FROM motorbike");
while ($row = $res->fetch_assoc()) {
    $models[$row['brand']][] = htmlspecialchars($row['model']);
}
$res = $conn->query("SELECT id, city_start, city_end FROM street");
while ($row = $res->fetch_assoc()) {
    $streets[] = [
        'id' => $row['id'],
        'name' => htmlspecialchars($row['city_start']) . " - " . htmlspecialchars($row['city_end'])
    ];
}
$conn->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['logout'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Invalid CSRF token.");
    }
    $brand = htmlspecialchars($_POST['brand'] ?? '');
    $model = htmlspecialchars($_POST['model'] ?? '');
    $street = htmlspecialchars($_POST['street'] ?? '');
    $_SESSION['brand'] = $brand;
    $_SESSION['model'] = $model;
    header("Location: Dashboard.php?street_id=" . urlencode($street));
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Select Motorbike and Route</title>
    <style>
        #news-carousel-container {
            max-width: 600px;
            margin: 30px auto 0 auto;
            position: relative;
        }
        #news-container {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
            padding: 10px;
            min-height: 200px;
        }
        .news-card {
            background: #fff;
            border-radius: 12px;
            padding: 15px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            transition: transform 0.2s;
            min-width: 0;
        }
        .news-card:hover {
            transform: scale(1.02);
        }
        .news-card h3 {
            font-size: 18px;
            margin: 0 0 10px;
        }
        .news-card p {
            font-size: 14px;
            color: #555;
        }
        .carousel-arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: #eee;
            border: none;
            border-radius: 50%;
            width: 36px;
            height: 36px;
            font-size: 22px;
            cursor: pointer;
            z-index: 2;
        }
        #carousel-prev {
            left: -45px;
        }
        #carousel-next {
            right: -45px;
        }
        #carousel-page-indicator {
            text-align: center;
            margin-top: 8px;
            font-size: 15px;
            color: #333;
        }
    </style>
    <script>
        // Models for each brand
        const models = <?php echo json_encode($models); ?>;
        function updateModels() {
            const brand = document.getElementById('brand').value;
            const modelSelect = document.getElementById('model');
            modelSelect.innerHTML = '';
            if (models[brand]) {
                models[brand].forEach(function(m) {
                    const opt = document.createElement('option');
                    opt.value = m;
                    opt.textContent = m;
                    modelSelect.appendChild(opt);
                });
                modelSelect.disabled = false;
            } else {
                modelSelect.disabled = true;
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <div style="display: flex; align-items: center; gap: 12px;">
            <img src="img/ProfiloDefault.png" alt="Profilo" style="width:40px; height:40px; border-radius:50%; object-fit:cover;">
            <span style="font-size: 1.3em; font-weight: bold;">
                <?= htmlspecialchars($username) ?> - <?= $welcome_message ?>
            </span>
        </div>
        <form method="post" style="margin-bottom:15px;">
            <button type="submit" name="logout">Logout</button>
        </form>
        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'ADMIN'): ?>
            <button type="button" onclick="window.location.href='UserProfile.php'">User Profile</button>
        <?php endif; ?>
        <form method="post" autocomplete="off">
            <label for="brand">Motorbike brand:</label>
            <select name="brand" id="brand" onchange="updateModels()" required>
                <option value="">Select brand</option>
                <?php foreach ($brands as $b): ?>
                    <option value="<?= $b ?>"><?= $b ?></option>
                <?php endforeach; ?>
            </select>
            <br>
            <label for="model">Motorbike model:</label>
            <select name="model" id="model" disabled required>
                <option value="">Select model</option>
            </select>
            <br>
            <label for="street">Route:</label>
            <select name="street" id="street" required>
                <option value="">Select route</option>
                <?php foreach ($streets as $s): ?>
                    <option value="<?= htmlspecialchars($s['id']) ?>"><?= $s['name'] ?></option>
                <?php endforeach; ?>
            </select>
            <br>
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
            <button type="submit">Submit</button>
        </form>
    </div>

    <div id="news-carousel-container">
        <button id="carousel-prev" class="carousel-arrow" style="display:none">&#8592;</button>
        <div id="news-container"></div>
        <button id="carousel-next" class="carousel-arrow" style="display:none">&#8594;</button>
        <div id="carousel-page-indicator"></div>
    </div>
    <script>
        let allNews = [];
        let currentNewsPage = 1;
        const newsPerPage = 3;

        async function loadNews() {
            const url = "https://api.allorigins.win/raw?url=https://www.moto.it/rss/news.xml";
            try {
                const response = await fetch(url);
                if (!response.ok) throw new Error("Unable to fetch news feed.");
                const text = await response.text();
                const parser = new DOMParser();
                const xml = parser.parseFromString(text, "application/xml");
                const items = xml.querySelectorAll("item");
                allNews = [];
                items.forEach((item, i) => {
                    if (i < 50) { // aumenta il limite delle notizie visualizzate
                        const title = item.querySelector("title")?.textContent || "";
                        const link = item.querySelector("link")?.textContent || "#";
                        const desc = item.querySelector("description")?.textContent || "";
                        // Try to get image from <enclosure>
                        let imgSrc = "";
                        const enclosure = item.querySelector("enclosure[url]");
                        if (enclosure) {
                            imgSrc = enclosure.getAttribute("url");
                        } else {
                            const imgMatch = desc.match(/<img[^>]+src="([^">]+)"/);
                            if (imgMatch) imgSrc = imgMatch[1];
                        }
                        allNews.push({
                            title, link, desc, imgSrc
                        });
                    }
                });
                renderNewsCarousel(1);
            } catch (err) {
                document.getElementById("news-container").innerHTML =
                    "<div class='news-card'><p>Unable to load news feed.</p></div>";
                document.getElementById("carousel-prev").style.display = "none";
                document.getElementById("carousel-next").style.display = "none";
                document.getElementById("carousel-page-indicator").textContent = "";
            }
        }

        function renderNewsCarousel(page) {
            const start = (page - 1) * newsPerPage;
            const paginated = allNews.slice(start, start + newsPerPage);
            let html = "";
            if (paginated.length === 0) {
                html = "<div class='news-card'><p>No news available.</p></div>";
            } else {
                paginated.forEach(news => {
                    html += `
                        <div class="news-card">
                            <a href="${news.link}" target="_blank">
                                ${news.imgSrc ? `<img src="${news.imgSrc}" alt="News image">` : ""}
                                <h3>${news.title}</h3>
                                <p>${news.desc.replace(/<img[^>]*>/, "")}</p>
                            </a>
                        </div>`;
                });
            }
            document.getElementById("news-container").innerHTML = html;
            currentNewsPage = page;
            const totalPages = Math.ceil(allNews.length / newsPerPage);
            document.getElementById("carousel-page-indicator").textContent =
                totalPages > 1 ? `Page ${currentNewsPage} of ${totalPages}` : "";
            document.getElementById("carousel-prev").style.display = (currentNewsPage > 1) ? "block" : "none";
            document.getElementById("carousel-next").style.display = (currentNewsPage < totalPages) ? "block" : "none";
        }

        document.getElementById("carousel-prev").onclick = function() {
            if (currentNewsPage > 1) renderNewsCarousel(currentNewsPage - 1);
        };
        document.getElementById("carousel-next").onclick = function() {
            const totalPages = Math.ceil(allNews.length / newsPerPage);
            if (currentNewsPage < totalPages) renderNewsCarousel(currentNewsPage + 1);
        };

        loadNews();
    </script>
</body>
</html>