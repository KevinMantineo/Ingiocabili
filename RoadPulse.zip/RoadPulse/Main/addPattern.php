<?php
session_start();
require_once("../db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: Homepage.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $city_start = $_POST['city_start'] ?? '';
    $city_end = $_POST['city_end'] ?? '';
    $description = $_POST['description'] ?? '';
    $coords = $_POST['coords'] ?? '';

    // Decodifica i punti cliccati
    $points_arr = json_decode($coords, true);
    $coo_start = $coo_end = '';
    $point_fields = array_fill(0, 10, null);

    if (is_array($points_arr) && count($points_arr) >= 2) {
        $coo_start = $points_arr[0]['lat'] . ',' . $points_arr[0]['lng'];
        $coo_end   = $points_arr[count($points_arr)-1]['lat'] . ',' . $points_arr[count($points_arr)-1]['lng'];

        $waypoints = array_slice($points_arr, 1, count($points_arr)-2);
        foreach ($waypoints as $i => $wp) {
            if ($i < 10) {
                $point_fields[$i] = $wp['lat'] . ',' . $wp['lng'];
            }
        }
    }

    $stmt = $conn->prepare("
        INSERT INTO street 
        (city_start, city_end, coo_start, coo_end,
         point1, point2, point3, point4, point5,
         point6, point7, point8, point9, point10,
         description, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    ");

    $stmt->bind_param(
        'sssssssssssssss',
        $city_start,
        $city_end,
        $coo_start,
        $coo_end,
        $point_fields[0],
        $point_fields[1],
        $point_fields[2],
        $point_fields[3],
        $point_fields[4],
        $point_fields[5],
        $point_fields[6],
        $point_fields[7],
        $point_fields[8],
        $point_fields[9],
        $description
    );

    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Pattern inviato per approvazione!');window.location.href='Homepage.php';</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Aggiungi Pattern</title>

    <!-- CSS PERSONALIZZATO -->
    <link rel="stylesheet" href="../styles/addpattern.css">

</head>
<body>

<div class="addpattern-container">
<div class="addpattern-card">

    <h2>Aggiungi un nuovo percorso</h2>

    <form method="post" onsubmit="return saveCoords();">

        <label>Città di partenza:</label>
        <input type="text" name="city_start" required>

        <label>Città di arrivo:</label>
        <input type="text" name="city_end" required>

        <label>Descrizione:</label>
        <input type="text" name="description" required>

        <label>Seleziona i punti sulla mappa:</label>

        <div class="map-wrapper">
            <div id="map"></div>
        </div>

        <input type="hidden" name="coords" id="coords" required>

        <p class="addpattern-help">
            Puoi inserire fino a 10 waypoint intermedi.  
            Clicca sulla mappa per aggiungere i punti del percorso.
        </p>

        <button class="btn-primary" type="submit">Invia richiesta</button>

    </form>

    <a class="back-link" href="Homepage.php">⟵ Torna indietro</a>

</div>
</div>

<script>
let map;
let markers = [];
let clickedPoints = [];
let directionsService;
let directionsRenderer;
let routePolylineCoords = [];

function initMap() {

    map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 43.1, lng: 12.4 },
        zoom: 8,
    });

    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer({
        map: map,
        suppressMarkers: true
    });

    // FIX per il problema della mappa nera
    setTimeout(() => {
        google.maps.event.trigger(map, "resize");
        map.setCenter({ lat: 43.1, lng: 12.4 });
    }, 300);

    map.addListener("click", function(e) {
        addPoint(e.latLng);
    });
}

function addPoint(latLng) {
    if (clickedPoints.length >= 12) {
        alert("Puoi inserire al massimo 10 waypoint intermedi.");
        return;
    }

    const marker = new google.maps.Marker({
        position: latLng,
        map: map
    });

    markers.push(marker);
    clickedPoints.push({ lat: latLng.lat(), lng: latLng.lng() });

    if (clickedPoints.length >= 2) {
        drawRoute();
    }
}

function drawRoute() {

    const waypoints = clickedPoints
        .slice(1, -1)
        .slice(0, 10)
        .map(pt => ({ location: pt, stopover: false }));

    directionsService.route({
        origin: clickedPoints[0],
        destination: clickedPoints[clickedPoints.length - 1],
        waypoints: waypoints,
        travelMode: google.maps.TravelMode.DRIVING
    }, function(response, status) {

        if (status === "OK") {
            directionsRenderer.setDirections(response);
            const route = response.routes[0].overview_path;

            routePolylineCoords = route.map(latlng => ({
                lat: latlng.lat(),
                lng: latlng.lng()
            }));
        } else {
            alert("Errore nel calcolo del percorso: " + status);
        }
    });
}

function saveCoords() {
    if (clickedPoints.length < 2) {
        alert("Clicca almeno due punti sulla mappa.");
        return false;
    }

    document.getElementById("coords").value = JSON.stringify(clickedPoints);
    return true;
}
</script>


<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB_cEu5Bqsuvs4b1kWBP4vxZdU1vZJOlNI&callback=initMap" async defer></script>

</body>
</html>
