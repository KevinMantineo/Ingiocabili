<?php
require '../db.php';
session_start();

$role = $_SESSION['role'] ?? 'USER';

// Recupera l'id della richiesta
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Recupera la richiesta dalla tabella street (solo pending)
$stmt = $conn->prepare("SELECT * FROM street WHERE id = ? AND status = 'pending'");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

if (!$row) {
    echo "<script>alert('Richiesta non trovata o già gestita');window.location.href='Homepage.php';</script>";
    exit;
}

$city_start  = $row['city_start'];
$city_end    = $row['city_end'];
$description = $row['description'];

// Ricostruisco i waypoints nell’ordine: start, point1..10, end
$user_waypoints = [];

$addWp = function($coo) use (&$user_waypoints) {
    if (!empty($coo)) {
        $parts = explode(',', $coo);
        if (count($parts) == 2) {
            $user_waypoints[] = [
                'lat' => floatval($parts[0]),
                'lng' => floatval($parts[1])
            ];
        }
    }
};

$addWp($row['coo_start']);
foreach (['point1','point2','point3','point4','point5','point6','point7','point8','point9','point10'] as $p) {
    $addWp($row[$p]);
}
$addWp($row['coo_end']);

?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Richiesta #<?= htmlspecialchars($id) ?></title>
    <link rel="stylesheet" href="../styles/viewrequest.css">

    <script>
        const userWaypoints = <?= json_encode($user_waypoints) ?>;

        function initMap() {
            if (!userWaypoints || userWaypoints.length < 2) {
                document.getElementById("map").innerHTML =
                    "<em>Percorso non trovato o coordinate mancanti.</em>";
                return;
            }

            const map = new google.maps.Map(document.getElementById("map"), {
                center: userWaypoints[0],
                zoom: 11
            });

            // Marker partenza e arrivo
            new google.maps.Marker({ position: userWaypoints[0], map: map, label: "A" });
            new google.maps.Marker({ position: userWaypoints[userWaypoints.length-1], map: map, label: "B" });

            // Marker intermedi (solo come riferimento per l'admin)
            for (let i = 1; i < userWaypoints.length-1; i++) {
                new google.maps.Marker({
                    position: userWaypoints[i],
                    map: map,
                    label: String(i),
                    title: "Waypoint " + i
                });
            }

            const directionsService = new google.maps.DirectionsService();
            const directionsRenderer = new google.maps.DirectionsRenderer({
                map: map,
                suppressMarkers: true
            });

            // Waypoints per la Directions API (tutti tranne primo e ultimo)
            const apiWaypoints = [];
            if (userWaypoints.length > 2) {
                for (let i = 1; i < userWaypoints.length - 1; i++) {
                    apiWaypoints.push({
                        location: userWaypoints[i],
                        stopover: false
                    });
                }
            }

            directionsService.route({
                origin:      userWaypoints[0],
                destination: userWaypoints[userWaypoints.length-1],
                waypoints:   apiWaypoints,
                travelMode:  google.maps.TravelMode.DRIVING
            }, function(response, status) {
                if (status === "OK") {
                    directionsRenderer.setDirections(response);
                } else {
                    alert("Impossibile calcolare il percorso: " + status);
                }
            });
        }

        window.initMap = initMap;
    </script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB_cEu5Bqsuvs4b1kWBP4vxZdU1vZJOlNI&callback=initMap" async defer></script>
</head>
<body>

<div class="request-container">

    <h2>Richiesta #<?= htmlspecialchars($id) ?></h2>

    <p><b>Città di partenza:</b> <?= htmlspecialchars($city_start) ?></p>
    <p><b>Città di arrivo:</b> <?= htmlspecialchars($city_end) ?></p>
    <p><b>Descrizione:</b> <?= nl2br(htmlspecialchars($description)) ?></p>

    <p><b>Waypoints inseriti dall'utente:</b></p>
    <ul>
        <?php foreach ($user_waypoints as $i => $wp): ?>
            <li>Waypoint <?= $i+1 ?> → LAT: <?= htmlspecialchars($wp['lat']) ?> / LNG: <?= htmlspecialchars($wp['lng']) ?></li>
        <?php endforeach; ?>
    </ul>

    <div id="map"></div>

    <form method="post">
        <?php if ($role === 'ADMIN' || $role === 'MOD'): ?>
            <button class="btn-primary" type="submit" name="action" value="accept">Approva</button>
            <button class="btn-secondary" type="submit" name="action" value="reject">Rifiuta</button>
        <?php endif; ?>
        <a href="Homepage.php" class="back-link">⟵ Torna indietro</a>
    </form>

</div>

</body>
</html>
<?php
// Logica approvazione / rifiuto dopo il rendering
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($role !== 'ADMIN' && $role !== 'MOD') {
        echo "<script>alert('Permesso negato');</script>";
        exit;
    }

    if ($_POST['action'] === 'accept') {
        $stmt = $conn->prepare("UPDATE street SET status = 'approved' WHERE id = ?");
    } else {
        $stmt = $conn->prepare("UPDATE street SET status = 'rejected' WHERE id = ?");
    }

    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Percorso aggiornato!');window.location.href='Homepage.php';</script>";
    exit;
}

$conn->close();
?>
