<?php
session_start();
require_once("../db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: Homepage.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$username = htmlspecialchars($_SESSION['username'] ?? '');
$role = $_SESSION['role'] ?? 'USER';

/* ---------------------------
   ELIMINAZIONE ACCOUNT (ADMIN)
--------------------------- */
if (isset($_POST['delete_id']) && $role === 'ADMIN') {
    $delete_id = intval($_POST['delete_id']);

    // Impedisce all'admin di auto-eliminarsi
    if ($delete_id != $user_id) {

        // per eliminare anche i percorsi o commenti creati da questo utente.

        $stmt = $conn->prepare("DELETE FROM account WHERE id = ?");
        $stmt->bind_param("i", $delete_id);

        if ($stmt->execute()) {
            $delete_message = "Account con ID $delete_id eliminato con successo.";
        } else {
            $delete_message = "Errore durante l'eliminazione dell'account.";
        }
        $stmt->close();

        // Reindirizza per ricaricare la tabella senza l'account eliminato
        header("Location: userprofile.php?msg=" . urlencode($delete_message));
        exit;
    } else {
        $delete_message = "Non puoi eliminare il tuo account da questa interfaccia.";
        header("Location: userprofile.php?msg=" . urlencode($delete_message));
        exit;
    }
}


/* ---------------------------
   AGGIORNAMENTO USERNAME
--------------------------- */
if (isset($_POST['new_username']) && !empty($_POST['new_username'])) {
    $new_username = $_POST['new_username'];
    $stmt = $conn->prepare("UPDATE account SET username = ? WHERE id = ?");
    $stmt->bind_param("si", $new_username, $user_id);
    $stmt->execute();
    $stmt->close();
    $_SESSION['username'] = $new_username;
    $username_update_message = "Username aggiornato con successo!";
}

/* ---------------------------
   AGGIORNAMENTO EMAIL
--------------------------- */
if (isset($_POST['new_email']) && !empty($_POST['new_email'])) {
    $new_email = $_POST['new_email'];
    $stmt = $conn->prepare("UPDATE account SET email = ? WHERE id = ?");
    $stmt->bind_param("si", $new_email, $user_id);
    $stmt->execute();
    $stmt->close();
    $email_update_message = "Email aggiornata con successo!";
}

/* ---------------------------
   AGGIORNAMENTO PASSWORD
--------------------------- */
if (isset($_POST['old_password'], $_POST['new_password'])) {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];

    $stmt = $conn->prepare("SELECT password FROM account WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($db_password_hash);
    $stmt->fetch();
    $stmt->close();

    if (password_verify($old_password, $db_password_hash)) {
        $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE account SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $new_hash, $user_id);
        $stmt->execute();
        $stmt->close();
        $password_update_message = "Password aggiornata con successo!";
    } else {
        $password_update_message = "La password attuale non è corretta.";
    }
}

/* ---------------------------
   UPLOAD IMMAGINE PROFILO
--------------------------- */
if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
    $imgData = file_get_contents($_FILES['profile_image']['tmp_name']);
    $stmt = $conn->prepare("UPDATE account SET image = ? WHERE id = ?");
    $stmt->bind_param("bi", $null, $user_id);
    $null = NULL;
    $stmt->send_long_data(0, $imgData);
    $stmt->execute();
    $stmt->close();

    $_SESSION['profile_img'] = 'data:image/jpeg;base64,' . base64_encode($imgData);
    $_SESSION['profile_img_selected'] = 'custom';

    $profile_image_message = "Immagine profilo aggiornata!";
}

/* ---------------------------
   SELEZIONE IMMAGINE PROFILO
--------------------------- */
$stmt = $conn->prepare("SELECT id, username, email, role, image FROM account WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($id, $uname, $email, $urole, $image_blob);
$stmt->fetch();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Profilo Utente</title>
    <link rel="stylesheet" href="../styles/userprofile.css">
</head>

<body>
<div class="profile-page-container">

    <!-- =========================== -->
    <!--   TORNA ALLA HOMEPAGE     -->
    <!-- =========================== -->
    <button class="return-home-btn" onclick="window.location.href='Homepage.php'">Torna alla Homepage</button>

    <!-- =========================== -->
    <!--      CARD PROFILO UTENTE   -->
    <!-- =========================== -->
    <div class="profile-card">
        <h2>Le tue credenziali</h2>

        <!-- Avatar -->
        <?php if ($image_blob): ?>
            <img class="profile-img" src="data:image/jpeg;base64,<?= base64_encode($image_blob) ?>" alt="Profilo">
        <?php else: ?>
            <img class="profile-img" src="img/ProfiloDefault.png" alt="Profilo">
        <?php endif; ?>

        <!-- Upload immagine -->
        <form method="post" enctype="multipart/form-data">
            <input type="file" name="profile_image" accept="image/*" required>
            <button class="btn-primary" type="submit">Aggiorna immagine profilo</button>
        </form>

        <!-- Dati utente -->
        <table class="profile-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Ruolo</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= htmlspecialchars($id) ?></td>
                    <td><?= htmlspecialchars($uname) ?></td>
                    <td><?= htmlspecialchars($email) ?></td>
                    <td><?= htmlspecialchars($urole) ?></td>
                </tr>
            </tbody>
        </table>

        <!-- Cambia username -->
        <h3>Cambia username</h3>
        <form method="post">
            <input type="text" name="new_username" placeholder="Nuovo username" required>
            <button class="btn-primary" type="submit">Aggiorna username</button>
        </form>
        <?php if (isset($username_update_message)): ?><p><?= $username_update_message ?></p><?php endif; ?>

        <!-- Cambia email -->
        <h3>Cambia email</h3>
        <form method="post">
            <input type="email" name="new_email" placeholder="Nuova email" required>
            <button class="btn-primary" type="submit">Aggiorna email</button>
        </form>
        <?php if (isset($email_update_message)): ?><p><?= $email_update_message ?></p><?php endif; ?>

        <!-- Cambia password -->
        <h3>Cambia password</h3>
        <form method="post">
            <input type="password" name="old_password" placeholder="Password attuale" required>
            <input type="password" name="new_password" placeholder="Nuova password" required>
            <button class="btn-primary" type="submit">Aggiorna password</button>
        </form>
        <?php if (isset($password_update_message)): ?><p><?= $password_update_message ?></p><?php endif; ?>

    </div>

    <!-- =========================== -->
    <!--   SEZIONE ADMIN  -->
    <!-- =========================== -->
    <?php if ($role === 'ADMIN'): ?>
    <div class="admin-section">
        <h2>Tutti gli account</h2>

        <table class="profile-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Ruolo</th>
                    <th>Azioni</th>
                </tr>
            </thead>
            <tbody>

            <?php
            $result = $conn->query("SELECT id, username, email, role FROM account");

            while ($row = $result->fetch_assoc()):
            ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['username']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td><?= htmlspecialchars($row['role']) ?></td>
                    <td>
                        <?php if ($row['id'] != $user_id): ?>
                            <form method="post" style="display:inline;" onsubmit="return confirm('Sei sicuro di voler eliminare questo account?');">
                                <input type="hidden" name="delete_id" value="<?= $row['id'] ?>">
                                <button class="btn-secondary" type="submit">Elimina</button>
                            </form>
                        <?php else: ?>
                            <em>Tu</em>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>

            </tbody>
        </table>

        <h2>Richieste di approvazione nuovi percorsi</h2>

        <table class="profile-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Città partenza</th>
                    <th>Città arrivo</th>
                    <th>Descrizione</th>
                    <th>Azioni</th>
                </tr>
            </thead>
            <tbody>

            <?php
            if (isset($_POST['approve_pattern'])) {
                $req_id = intval($_POST['approve_pattern']);
                $conn->query("UPDATE street SET status='approved' WHERE id=$req_id");
            }

            if (isset($_POST['reject_pattern'])) {
                $req_id = intval($_POST['reject_pattern']);
                $conn->query("UPDATE street SET status='rejected' WHERE id=$req_id");
            }

            $result = $conn->query("SELECT id, city_start, city_end, description FROM street WHERE status='pending'");
            while ($row = $result->fetch_assoc()):
            ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['city_start']) ?></td>
                    <td><?= htmlspecialchars($row['city_end']) ?></td>
                    <td><?= htmlspecialchars($row['description']) ?></td>
                    <td>
                        <form method="post" style="display:inline;">
                            <button class="btn-primary" type="submit" name="approve_pattern" value="<?= $row['id'] ?>">Approva</button>
                        </form>

                        <form method="post" style="display:inline;">
                            <button class="btn-secondary" type="submit" name="reject_pattern" value="<?= $row['id'] ?>">Rifiuta</button>
                        </form>

                        <form method="get" action="viewrequest.php" style="display:inline;">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <button class="btn-secondary" type="submit">View</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>

            </tbody>
        </table>
    </div>
    <?php endif; ?>

</div>
</body>
</html>
