<?php
session_start();
require_once("../db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: Homepage.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$username = htmlspecialchars($_SESSION['username'] ?? '');
$role = $_SESSION['role'] ?? 'USER';

// Aggiorna username
if (isset($_POST['new_username']) && !empty($_POST['new_username'])) {
    $new_username = $_POST['new_username'];
    $stmt = $conn->prepare("UPDATE account SET username = ? WHERE id = ?");
    $stmt->bind_param("si", $new_username, $user_id);
    $stmt->execute();
    $stmt->close();
    $_SESSION['username'] = $new_username;
    $username_update_message = "Username aggiornato con successo!";
}

// Aggiorna email
if (isset($_POST['new_email']) && !empty($_POST['new_email'])) {
    $new_email = $_POST['new_email'];
    $stmt = $conn->prepare("UPDATE account SET email = ? WHERE id = ?");
    $stmt->bind_param("si", $new_email, $user_id);
    $stmt->execute();
    $stmt->close();
    $email_update_message = "Email aggiornata con successo!";
}

// Aggiorna password
if (isset($_POST['old_password'], $_POST['new_password'])) {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $stmt = $conn->prepare("SELECT password FROM account WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($db_password_hash);
    $stmt->fetch();
    $stmt->close();
    if (password_verify($old_password, $db_password_hash)) {
        $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE account SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $new_hash, $user_id);
        $stmt->execute();
        $stmt->close();
        $password_update_message = "Password aggiornata con successo!";
    } else {
        $password_update_message = "La password attuale non è corretta.";
    }
}

// Recupera le credenziali aggiornate
$stmt = $conn->prepare("SELECT id, username, email, role FROM account WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($id, $uname, $email, $urole);
$stmt->fetch();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Profilo Utente</title>
</head>
<body>
    <h2>Le tue credenziali</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Ruolo</th>
        </tr>
        <tr>
            <td><?= htmlspecialchars($id) ?></td>
            <td><?= htmlspecialchars($uname) ?></td>
            <td><?= htmlspecialchars($email) ?></td>
            <td><?= htmlspecialchars($urole) ?></td>
        </tr>
    </table>

    <h3>Cambia username</h3>
    <form method="post">
        <input type="text" name="new_username" placeholder="Nuovo username" required>
        <button type="submit">Aggiorna username</button>
    </form>
    <?php if (isset($username_update_message)): ?>
        <p><?= $username_update_message ?></p>
    <?php endif; ?>

    <h3>Cambia email</h3>
    <form method="post">
        <input type="email" name="new_email" placeholder="Nuova email" required>
        <button type="submit">Aggiorna email</button>
    </form>
    <?php if (isset($email_update_message)): ?>
        <p><?= $email_update_message ?></p>
    <?php endif; ?>

    <h3>Cambia password</h3>
    <form method="post">
        <input type="password" name="old_password" placeholder="Password attuale" required>
        <input type="password" name="new_password" placeholder="Nuova password" required>
        <button type="submit">Aggiorna password</button>
    </form>
    <?php if (isset($password_update_message)): ?>
        <p><?= $password_update_message ?></p>
    <?php endif; ?>

    <?php if ($role === 'ADMIN'): ?> 
        <h2>Tutti gli account</h2>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Ruolo</th>
                <th>Azioni</th>
            </tr>
            <?php
            $result = $conn->query("SELECT id, username, email, role FROM account");
            while ($row = $result->fetch_assoc()):
            ?>
            <tr>
                <td><?= htmlspecialchars($row['id']) ?></td>
                <td><?= htmlspecialchars($row['username']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['role']) ?></td>
                <td>
                    <?php if ($row['id'] != $user_id): ?>
                    <form method="post" style="display:inline;" onsubmit="return confirm('Sei sicuro di voler eliminare questo account?');">
                        <input type="hidden" name="delete_id" value="<?= htmlspecialchars($row['id']) ?>">
                        <button type="submit">Elimina</button>
                    </form>
                    <?php else: ?>
                        <em>Tu</em>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    <?php endif; ?>
</body>
</html>