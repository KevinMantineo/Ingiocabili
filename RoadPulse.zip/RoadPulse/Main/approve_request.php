<?php
require '../db.php';
session_start();

if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'ADMIN' && $_SESSION['role'] !== 'MOD')) {
    echo "<script>alert('Permesso negato');window.location.href='Homepage.php';</script>";
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    echo "<script>alert('ID non valido');window.location.href='Homepage.php';</script>";
    exit;
}

// Recupera la richiesta
$res = $conn->query("SELECT * FROM pattern_requests WHERE id=$id");
if (!$res || $res->num_rows == 0) {
    echo "<script>alert('Richiesta non trovata');window.location.href='Homepage.php';</script>";
    exit;
}
$row = $res->fetch_assoc();

// Aggiorna solo lo stato della richiesta
$conn->query("UPDATE pattern_requests SET status = 'approved' WHERE id = $id");

echo "<script>alert('Pattern approvato!');window.location.href='Homepage.php';</script>";
$conn->close();
exit;
