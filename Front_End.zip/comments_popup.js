// Apri popup quando clicchi il bottone "Commenti"
document.querySelector(".commenti").addEventListener("click", function () {
    document.getElementById("commentsPopup").style.display = "flex";
});

// Chiudi popup
document.getElementById("closePopup").addEventListener("click", function () {
    document.getElementById("commentsPopup").style.display = "none";
});
