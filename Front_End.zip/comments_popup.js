// elementi popup
const btnCommenti = document.querySelector(".commenti");
const popup = document.getElementById("commentsPopup");
const closeBtn = document.getElementById("closePopup");

// stile overlay
if (popup) {
    popup.style.position = "fixed";
    popup.style.inset = "0";
    popup.style.background = "rgba(0,0,0,0.55)";
    popup.style.display = "none";
    popup.style.justifyContent = "center";
    popup.style.alignItems = "center";
    popup.style.zIndex = "9999";
    popup.style.transition = "opacity 0.3s ease";
}

const content = popup?.querySelector(".popup-content");

// stile box centrale
if (content) {
    content.style.background = "#fff";
    content.style.border = "2px solid #864300";
    content.style.borderRadius = "18px";
    content.style.padding = "22px";
    content.style.width = "380px";
    content.style.maxHeight = "540px";
    content.style.overflowY = "auto";
    content.style.boxShadow = "0 6px 18px rgba(0,0,0,0.25)";
    content.style.display = "flex";
    content.style.flexDirection = "column";
    content.style.gap = "12px";
    content.style.animation = "popupEntrance 0.25s ease forwards";

    const title = content.querySelector("h2");
    if (title) {
        title.innerHTML = `<i class="fa-solid fa-comment-dots"></i> Commenti del percorso`;
        title.style.textAlign = "center";
        title.style.color = "#864300";
        title.style.marginTop = "0";
    }
}

// apri popup
if (btnCommenti) {
    btnCommenti.addEventListener("click", () => {
        popup.style.display = "flex";
        popup.style.opacity = "0";
        setTimeout(() => popup.style.opacity = "1", 20);
    });
}

// chiudi popup
if (closeBtn) {
    closeBtn.style.background = "#864300";
    closeBtn.style.color = "white";
    closeBtn.style.borderRadius = "8px";

    closeBtn.addEventListener("click", () => {
        popup.style.opacity = "0";
        setTimeout(() => popup.style.display = "none", 250);
    });
}

// chiudi cliccando fuori
document.addEventListener("click", (e) => {
    if (e.target === popup) {
        popup.style.opacity = "0";
        setTimeout(() => popup.style.display = "none", 250);
    }
});

// textarea e invio
const textarea = document.getElementById("newComment");
const sendBtn = document.querySelector(".btn-send");

if (textarea) {
    textarea.style.border = "1.5px solid #864300";
    textarea.style.borderRadius = "8px";
}

if (sendBtn) {
    sendBtn.style.background = "#864300";
    sendBtn.style.color = "white";
    sendBtn.style.borderRadius = "8px";

    sendBtn.addEventListener("click", () => {
        const text = textarea.value.trim();
        if (!text) return;

        const newCard = document.createElement("div");
        newCard.classList.add("comment-card");
        newCard.style.background = "#f7f3ef";
        newCard.style.padding = "10px";
        newCard.style.borderRadius = "8px";

        newCard.innerHTML = `<strong>Tu</strong><p>${text}</p>`;
        content.insertBefore(newCard, textarea);
        textarea.value = "";
    });
}

// animazione zoom
const style = document.createElement("style");
style.innerHTML = `
@keyframes popupEntrance {
    from { opacity: 0; transform: scale(0.8); }
    to   { opacity: 1; transform: scale(1); }
}`;
document.head.appendChild(style);
