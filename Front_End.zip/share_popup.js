// bottone condividi
const shareBtn = document.querySelector(".condividi");

if (shareBtn) {
    shareBtn.addEventListener("click", showSharePopup);
}

function showSharePopup() {
    const old = document.getElementById("sharePopup");
    if (old) old.remove();

    const overlay = document.createElement("div");
    overlay.id = "sharePopup";
    overlay.style.position = "fixed";
    overlay.style.inset = "0";
    overlay.style.background = "rgba(0,0,0,0.55)";
    overlay.style.display = "flex";
    overlay.style.justifyContent = "center";
    overlay.style.alignItems = "center";
    overlay.style.zIndex = "9999";
    overlay.style.opacity = "0";

    const box = document.createElement("div");
    box.style.background = "#ffffff";
    box.style.border = "2px solid #864300";
    box.style.borderRadius = "15px";
    box.style.padding = "20px";
    box.style.width = "260px";
    box.style.boxShadow = "0 4px 12px rgba(245, 124, 0, 0.25)";
    box.style.display = "flex";
    box.style.flexDirection = "column";
    box.style.gap = "10px";
    box.style.textAlign = "center";

    box.innerHTML = `
        <h3 style="margin:0;color:#864300;">Condividi</h3>

        <button class="share-btn" id="whatsapp">📱 WhatsApp</button>
        <button class="share-btn" id="telegram">✈️ Telegram</button>
        <button class="share-btn" id="copy">📋 Copia link</button>

        <button class="share-btn" id="instagram">📸 Instagram</button>
        <button class="share-btn" id="tiktok">🎵 TikTok</button>
        <button class="share-btn" id="facebook">📘 Facebook</button>

        <button class="share-btn" id="close" style="background:#b10">Chiudi</button>
    `;

    overlay.appendChild(box);
    document.body.appendChild(overlay);

    setTimeout(() => (overlay.style.opacity = "1"), 20);

    // pulsanti social
    document.getElementById("whatsapp").onclick = () =>
        window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(window.location.href)}`);

    document.getElementById("telegram").onclick = () =>
        window.open(`https://t.me/share/url?url=${encodeURIComponent(window.location.href)}`);

    document.getElementById("copy").onclick = async () => {
        await navigator.clipboard.writeText(window.location.href);
        alert("Link copiato!");
    };

    // nuovi aggiunti
    document.getElementById("instagram").onclick = () =>
        window.open("https://www.instagram.com");

    document.getElementById("tiktok").onclick = () =>
        window.open("https://www.tiktok.com");

    document.getElementById("facebook").onclick = () =>
        window.open("https://www.facebook.com");

    // chiudi
    document.getElementById("close").onclick = () => overlay.remove();

    // stile pulsanti
    document.querySelectorAll(".share-btn").forEach(btn => {
        btn.style.background = "#864300";
        btn.style.color = "white";
        btn.style.border = "none";
        btn.style.padding = "10px";
        btn.style.borderRadius = "6px";
        btn.style.cursor = "pointer";
        btn.style.fontWeight = "700";
    });

    // chiudi clic fuori
    overlay.addEventListener("click", (e) => {
        if (e.target === overlay) overlay.remove();
    });
}
