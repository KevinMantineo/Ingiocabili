// Fade-in iniziale del box login
document.addEventListener("DOMContentLoaded", () => {
    const container = document.querySelector(".login-container");
    container.style.opacity = "0";

    setTimeout(() => {
        container.style.transition = "opacity 0.8s ease";
        container.style.opacity = "1";
    }, 80);
});

// Validazione base con animazione shake
document.getElementById("loginForm").addEventListener("submit", function (e) {
    const user = document.getElementById("username");
    const pass = document.getElementById("password");

    if (user.value.trim() === "" || pass.value.trim() === "") {
        e.preventDefault();

        const fields = [user, pass];

        fields.forEach(input => {
            input.style.borderColor = "rgb(185, 80, 80)";
            input.style.animation = "shake 0.3s";
            setTimeout(() => (input.style.animation = ""), 300);
        });
    }
});

// Aggiunge hover "soft" ai bottoni
document.querySelectorAll(".btn").forEach(btn => {
    btn.addEventListener("mouseover", () => {
        btn.style.transform = "scale(1.03)";
        btn.style.transition = "0.2s ease";
    });

    btn.addEventListener("mouseout", () => {
        btn.style.transform = "scale(1)";
    });
});
