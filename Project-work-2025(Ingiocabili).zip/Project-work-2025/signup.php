<?php
require '../db.php';
session_start();
$mysqli = new mysqli($servername, $username, $password, $dbname);



if (!isset($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(16));
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verifica token CSRF
    if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['csrf_token']) {
        $error = 'Token CSRF non valido.';
    } else {
        $email = trim($_POST['email'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Email non valida.';
        } elseif (strlen($username) < 3) {
            $error = 'Username troppo corto.';
        } elseif (strlen($password) < 6) {
            $error = 'Password troppo corta.';
        } else {
            $stmt = $mysqli->prepare('SELECT ID FROM account WHERE email = ? OR username = ?');
            $stmt->bind_param('ss', $email, $username);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $error = 'Email o username già registrati.';
            } else {
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $mysqli->prepare('INSERT INTO account (email, username, password) VALUES (?, ?, ?)');
                $stmt->bind_param('sss', $email, $username, $password_hash);
                if ($stmt->execute()) {

                    header('Location: login.php');
                    exit;
                } else {
                    $error = 'Errore durante la registrazione.';
                }
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
    <meta charset="UTF-8">
</head>
<body>
    <h2>Registrazione</h2>
    <?php if (!empty($error)) echo '<p style="color:red">' . htmlspecialchars($error) . '</p>'; ?>
    <form method="post" autocomplete="off">
        <label>Email:<br><input type="email" name="email" required></label><br>
        <label>Username:<br><input type="text" name="username" required></label><br>
        <label>Password:<br><input type="password" name="password" required></label><br>
        <input type="hidden" name="token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
        <button type="submit">Registrati</button>
    </form>
    <p>Hai già un account? <a href="/RoadPulse/login/login.php">Login</a></p>
</body>
</html>