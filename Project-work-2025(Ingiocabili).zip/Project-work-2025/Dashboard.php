<?php
session_start();

if (!isset($_SESSION['token'])) {
    header("Location: /RoadPulse/login/login.php");
    exit;
}


if (isset($_POST['logout'])) {
    $_SESSION = [];
    session_destroy();
    header("Location: /RoadPulse/login/login.php");
    exit;
}


if (!isset($_SESSION['first_login_done'])) {
    $messaggio = "Benvenuto";
    $_SESSION['first_login_done'] = true; 
} else {
    $messaggio = "Bentornato";
}

?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Homepage</title>
</head>
<body>
<div class="container">
    <h2><?= $messaggio ?>, <?= htmlspecialchars($_SESSION['username'] ?? 'Utente') ?>!</h2>
    <form method="post" style="margin-bottom:15px;">
        <button type="submit" name="logout">Logout</button>
    </form>
     <button type="button" onclick="window.location.href='UserProfile.php'">Profilo Utente</button>
    <hr>
    <p>Questa è la tua dashboard. Qui potrai vedere i tuoi dati e gestire il tuo account.</p>
</div>
</body>
</html>
</html>
