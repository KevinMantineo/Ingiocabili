document.addEventListener('DOMContentLoaded', function() {
    // Profile and logout banner logic
    const profileBtn = document.querySelector('.profile-btn');
    const logoutBtn = document.querySelector('.logout-btn');
    const infoBanner = document.getElementById('profile-info-dropdown');

    // Logout confirmation banner
    let logoutBanner = document.createElement('div');
    logoutBanner.id = 'logout-confirm-banner';
    logoutBanner.style.display = 'none';
    logoutBanner.style.position = 'absolute';
    logoutBanner.style.top = '60px';
    logoutBanner.style.right = '60px';
    logoutBanner.style.background = 'rgba(234,227,227,0.97)';
    logoutBanner.style.border = '2px solid #000';
    logoutBanner.style.borderRadius = '18px';
    logoutBanner.style.padding = '0';
    logoutBanner.style.zIndex = '1000';
    logoutBanner.style.width = '320px';
    logoutBanner.style.boxShadow = '0 4px 16px rgba(0,0,0,0.15)';
    logoutBanner.innerHTML = `
        <div style="padding:18px 12px;text-align:center;font-size:1.1em;color:#000;">
            Are you sure you want to logout?
        </div>
        <div style="display:flex;justify-content:space-between;padding:0 12px 12px 12px;">
            <button id="logout-yes" style="width:48%;padding:8px 0;border-radius:12px;border:2px solid #000;background:rgb(185,80,80);color:#fff;font-weight:bold;cursor:pointer;">Yes</button>
            <button id="logout-no" style="width:48%;padding:8px 0;border-radius:12px;border:2px solid #000;background:rgb(117,44,39);color:#fff;font-weight:bold;cursor:pointer;">No</button>
        </div>
    `;
    document.body.appendChild(logoutBanner);

    // Profile info banner on hover
    let profileTimer;
    profileBtn.addEventListener('mouseenter', function() {
        profileTimer = setTimeout(function() {
            infoBanner.style.display = "block";
            logoutBanner.style.display = "none";
        }, 1000);
    });
    profileBtn.addEventListener('mouseleave', function() {
        clearTimeout(profileTimer);
        infoBanner.style.display = "none";
    });

    // Show profile info banner on click
    profileBtn?.addEventListener('click', function(e) {
        e.stopPropagation();
        infoBanner.style.display = "block";
    });

    // Prevent banner from hiding when mouse is over it
    infoBanner?.addEventListener('mouseenter', function() {
        infoBanner.style.display = "block";
    });

    // Hide banner when clicking outside
    document.addEventListener('click', function(e) {
        if (!infoBanner.contains(e.target) && e.target !== profileBtn) {
            infoBanner.style.display = "none";
        }
    });

    // Logout confirmation banner on click
    logoutBtn?.addEventListener('click', function() {
        infoBanner.style.display = "none";
        logoutBanner.style.display = "block";
    });

    logoutBanner.addEventListener('click', function(e) {
        if (e.target.id === 'logout-no') {
            logoutBanner.style.display = "none";
        }
        if (e.target.id === 'logout-yes') {
            window.location.href = 'logout.php';
        }
    });

    // Dropdown logic for all select-boxes (brand, model, routes)
    document.querySelectorAll('.select-box').forEach(function(box) {
        const select = box.querySelector('select');
        if (select) {
            box.addEventListener('mouseenter', function() {
                select.style.display = "block";
                if (select.options.length > 0) {
                    select.selectedIndex = 0;
                }
            });
            box.addEventListener('mouseleave', function() {
                select.style.display = "none";
            });
            select.addEventListener('mouseenter', function() {
                select.style.display = "block";
            });
            select.addEventListener('mouseleave', function() {
                select.style.display = "none";
            });
            select.addEventListener('change', function() {
                select.style.display = "none";
            });
        }
    });

    // Show dropdown menu on click for BRAND, MODEL, ROUTES
    document.querySelectorAll('.select-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            // Hide all dropdowns
            document.querySelectorAll('.menu-select').forEach(function(menu) {
                menu.style.display = 'none';
            });
            // Show the clicked dropdown just below the button
            var targetId = btn.getAttribute('data-target');
            var menu = document.getElementById(targetId);
            if (menu) {
                menu.style.display = 'block';
                menu.focus();
            }
        });
    });

    // Hide dropdowns when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.classList.contains('select-btn') &&
            !e.target.classList.contains('menu-select')) {
            document.querySelectorAll('.menu-select').forEach(function(menu) {
                menu.style.display = 'none';
            });
        }
    });

    // Hide dropdown when an option is selected
    document.querySelectorAll('.menu-select').forEach(function(select) {
        select.addEventListener('change', function() {
            select.style.display = 'none';
        });
    });
});